# RondiTrack

RondiTrack is a RESTful ASP.NET Core Web API for managing stokvel users, stokvels, contribution cycles, contributions, and membership relationships.

The project is developed incrementally as part of the Bitcube backend training assignments. The implementation has progressed from in-memory persistence and API validation toward Entity Framework Core, PostgreSQL, explicit relationship modeling, query analysis, and production-oriented data-access practices.

---

## Technology Stack

* .NET 10
* ASP.NET Core Web API
* C#
* Entity Framework Core 10
* PostgreSQL
* Npgsql
* FluentValidation
* OpenAPI
* Scalar API Reference
* xUnit
* Moq
* Git / GitHub

---

# Architecture

RondiTrack follows a layered architecture:

```text
HTTP Request
     |
     v
Controllers
     |
     v
Services
     |
     v
Repositories / EF Core
     |
     v
RondiTrackDbContext
     |
     v
PostgreSQL
```

The application uses interfaces for repository boundaries and separates business logic from persistence concerns.

Database-backed functionality introduced in Assignments 5.1 and 5.2 uses Entity Framework Core and PostgreSQL.

---

# Domain Model

The main domain entities are:

* User
* Stokvel
* StokvelMember
* ContributionCycle
* Contribution

The important relationships are:

```text
User
  |
  | 1
  |
  | *
StokvelMember
  |
  | *
  |
  | 1
Stokvel
  |
  | 1
  |
  | *
ContributionCycle
  |
  | 1
  |
  | *
Contribution
```

A `User` can belong to many stokvels and a `Stokvel` can contain many users.

Because membership contains its own domain information, the many-to-many relationship is represented by the explicit `StokvelMember` entity.

---

# Assignment 5.1 — EF Core and PostgreSQL

Assignment 5.1 introduced database persistence for users using Entity Framework Core and PostgreSQL.

The database context is:

```text
Data/RondiTrackDbContext.cs
```

The PostgreSQL connection is configured through:

```text
appsettings.Development.json
```

The application uses Npgsql as the EF Core PostgreSQL provider.

The User repository uses Entity Framework Core for database-backed persistence.

---

# Assignment 5.2 — EF Core Relationships and Query Behaviour

Assignment 5.2 extends the database model to demonstrate real EF Core relationships and query behaviour.

The main objectives were:

1. Model User ↔ Stokvel as a real many-to-many relationship.
2. Use an explicit join entity containing membership data.
3. Use a composite primary key for membership.
4. Introduce a dedicated repository for the composite-key entity.
5. Add a real one-to-many relationship.
6. Generate and review EF Core migrations.
7. Deliberately demonstrate an N+1 query.
8. Measure the N+1 query count.
9. Fix the N+1 query using eager loading.
10. Fix the N+1 query using projection.
11. Compare the two fixes.
12. Audit read-only database queries for `AsNoTracking()`.
13. Document the final loading-strategy decision.
14. Re-run the existing test suite.
15. Document remaining implementation gaps.

---

# 1. User ↔ Stokvel Many-to-Many Relationship

The relationship between `User` and `Stokvel` is modeled as a real many-to-many relationship through:

```text
Models/StokvelMember.cs
```

The join entity contains:

```text
UserId
StokvelId
Role
JoinedAtUtc
```

This means membership is not simply a link between two IDs.

Membership itself contains domain information such as:

* the user's role within the stokvel
* the date on which the user joined

The relationship is therefore represented by an explicit domain entity rather than an implicit EF Core many-to-many join table.

---

# 2. Composite Primary Key

`StokvelMember` uses the following composite primary key:

```text
(UserId, StokvelId)
```

The EF Core configuration is equivalent to:

```csharp
entity.HasKey(member => new
{
    member.UserId,
    member.StokvelId
});
```

## Why a composite key?

A user can only have one membership record for a particular stokvel.

Therefore:

```text
User A + Stokvel X
```

uniquely identifies one membership.

A separate surrogate `MembershipId` would add another identifier without representing additional domain meaning.

The composite key also directly expresses the uniqueness rule of the relationship.

---

# 3. Membership and Contribution/Payout Identity

Because `StokvelMember` does not have a single `Id`, another entity that needs to identify a membership can use:

```text
UserId + StokvelId
```

as the membership reference.

For example, a contribution can identify the contributing user and the stokvel:

```text
UserId
StokvelId
```

The application can then resolve the corresponding membership using the composite key.

This keeps membership identity consistent with the domain relationship.

If future requirements require a contribution to reference a specific historical membership record independently of the user/stokvel pair, a dedicated membership identifier could be introduced as a later schema decision. That requirement is not currently necessary for the Assignment 5.2 domain.

---

# 4. Dedicated Repository for StokvelMember

The normal generic repository pattern uses a single identifier such as:

```csharp
GetByIdAsync(Guid id)
```

That pattern does not naturally represent `StokvelMember`, because membership identity consists of:

```text
UserId + StokvelId
```

Therefore a dedicated repository was introduced:

```text
Data/IStokvelMemberRepository.cs
Data/EfStokvelMemberRepository.cs
```

The repository exposes operations such as:

```csharp
GetAsync(Guid userId, Guid stokvelId)
GetByStokvelIdAsync(Guid stokvelId)
AddAsync(StokvelMember member)
DeleteAsync(Guid userId, Guid stokvelId)
```

EF Core can resolve the composite key using:

```csharp
FindAsync(userId, stokvelId)
```

This avoids forcing a generic single-ID repository abstraction onto an entity that has a composite identity.

---

# 5. Stokvel → ContributionCycle One-to-Many Relationship

A real one-to-many relationship was added between:

```text
Stokvel
    |
    | 1
    |
    | *
ContributionCycle
```

A stokvel can therefore contain multiple contribution cycles.

`Stokvel` contains:

```csharp
public ICollection<ContributionCycle> ContributionCycles { get; private set; }
```

`ContributionCycle` contains:

```csharp
public Guid StokvelId { get; }
public Stokvel Stokvel { get; private set; }
```

The relationship is configured using a foreign key from:

```text
ContributionCycle.StokvelId
```

to:

```text
Stokvel.Id
```

---

# 6. ContributionCycle → Contribution Relationship

Contributions belong to a particular contribution cycle.

The cycle is identified using:

```text
StokvelId + PeriodNumber
```

The contribution stores:

```text
StokvelId
Cycle
```

The EF Core model therefore uses an alternate key on:

```text
ContributionCycle(StokvelId, PeriodNumber)
```

and a composite foreign key from:

```text
Contribution(StokvelId, Cycle)
```

to:

```text
ContributionCycle(StokvelId, PeriodNumber)
```

This preserves the existing domain representation of contribution cycles while allowing EF Core to enforce the relationship in PostgreSQL.

---

# 7. Contribution → User Relationship

Contributions also contain:

```text
UserId
```

and have a navigation property to:

```text
User
```

This allows relationship queries to retrieve the user associated with each contribution.

The navigation is used by the query optimization work in Assignment 5.2.

---

# 8. EF Core Migrations

The relationship changes were introduced through EF Core migrations.

The migrations include the schema changes required for:

* `StokvelMember`
* the composite primary key
* User ↔ Stokvel foreign keys
* Stokvel ↔ ContributionCycle relationship
* ContributionCycle ↔ Contribution relationship
* contribution relationship indexes
* contribution/user relationship

The migrations are stored under:

```text
Migrations/
```

## Migration review

Before applying the migrations, the generated SQL/schema changes were reviewed.

The review checked that:

* new tables were created correctly
* primary keys matched the intended model
* the `StokvelMember` key was composite
* foreign keys pointed to the correct tables
* the contribution-cycle composite relationship used the correct principal key
* indexes were appropriate
* existing data was not unintentionally dropped
* `ALTER TABLE` operations were appropriate for existing tables
* required columns and constraints matched the C# model

The migration was then applied to PostgreSQL.

---

# 9. N+1 Query Investigation

Assignment 5.2 deliberately introduced the following endpoint:

```text
GET /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions
```

The purpose was to demonstrate the N+1 query problem.

The naive approach performs:

```text
1. Query the contribution cycle
2. Query its contributions
3. Query the User for contribution 1
4. Query the User for contribution 2
5. Query the User for contribution 3
...
```

For `N` contributions this results in approximately:

```text
N + 2 SQL queries
```

For example, with 5 contributions:

```text
1 cycle query
1 contribution query
5 user queries
----------------
7 SQL queries
```

This is the measured N+1 pattern used for the Assignment 5.2 investigation.

---

# 10. SQL Command Logging

EF Core database command logging was enabled during the investigation.

The logging records SQL commands executed by Entity Framework Core.

The relevant category is:

```text
Microsoft.EntityFrameworkCore.Database.Command
```

This allows the number of SQL commands generated by each query strategy to be observed directly.

The query count was measured by clearing/isolating the application console output before making the endpoint request and counting the executed database commands generated by that request.

Startup migration and seed commands were not included in the endpoint query count.

---

# 11. N+1 Fix — Eager Loading

The first fix uses EF Core eager loading.

The relationship is loaded using:

```csharp
.Include(cycle => cycle.Contributions)
.ThenInclude(contribution => contribution.User)
```

Conceptually:

```text
ContributionCycle
       |
       +-- Contributions
                |
                +-- User
```

The complete relationship graph is requested as part of the query rather than loading each user separately.

The endpoint therefore performs approximately:

```text
1 SQL query
```

for the complete relationship graph.

`AsSingleQuery()` is used where appropriate so the eager-loading strategy is intentionally executed as a single SQL query.

---

# 12. N+1 Fix — Projection

The second fix uses projection.

Instead of loading complete entity graphs, the query selects only the fields required by the API response.

The projection returns fields such as:

```text
Contribution Id
User Id
User Name
Amount
RecordedAt
Cycle Id
Stokvel Id
Period Number
```

Conceptually:

```csharp
.Select(...)
```

This allows EF Core to translate the requested fields into SQL and retrieve only the columns required by the response.

The projection also executes as a single database query.

---

# 13. N+1 Comparison

| Strategy      |                                  Expected Query Pattern | Query Count for 5 Contributions | Data Retrieved          |
| ------------- | ------------------------------------------------------: | ------------------------------: | ----------------------- |
| Naive / N+1   | Cycle + Contributions + one User query per contribution |                               7 | Multiple entity queries |
| Eager loading | Cycle + Contributions + Users in one relationship query |                               1 | Entity graph            |
| Projection    |               Required response fields in one SQL query |                               1 | Only required columns   |

The naive approach does not scale well because the number of SQL queries grows with the number of contributions.

The eager-loading approach removes the repeated user queries, but it can retrieve more entity data than the endpoint actually needs.

The projection approach retrieves only the columns required by the response.

---

# 14. Final Loading Strategy

The selected strategy for the contribution query endpoint is:

```text
Projection
```

Projection was selected because this endpoint is read-only and returns a specific response shape.

Advantages:

* one SQL query
* avoids N+1 behaviour
* retrieves only required columns
* avoids unnecessary entity materialization
* reduces unnecessary change tracking
* gives the API explicit control over its response data
* scales better as the number of contributions increases

Eager loading remains an appropriate strategy when the application genuinely needs the full related entity graph for subsequent domain operations.

---

# 15. No Lazy Loading

Lazy loading is deliberately not enabled.

The application does not rely on navigation properties automatically triggering database queries.

This is important because lazy loading can hide database calls inside normal property access and make N+1 problems difficult to see.

The application instead uses explicit strategies:

```text
Projection
Eager loading
Explicit query composition
```

This makes database access visible in the repository/query code and easier to measure.

---

# 16. AsNoTracking Audit

Read-only EF Core queries use:

```csharp
AsNoTracking()
```

where the returned entities do not need to be modified.

This avoids unnecessary EF Core change tracking and reduces overhead for read-heavy operations.

The database-backed membership read path uses `AsNoTracking()`.

The contribution collection read path also uses `AsNoTracking()`.

The N+1 investigation and both optimized query strategies use `AsNoTracking()` because the endpoint is read-only.

Shared repository methods that participate in write workflows are not blindly converted to no-tracking queries when doing so could break update/delete behaviour. This keeps read/write repository methods safe while allowing dedicated read-only paths to use no-tracking behaviour.

---

# 17. Repository Design

The project uses repository interfaces to separate persistence from business logic.

Examples include:

```text
IUserRepository
IStokvelRepository
IContributionRepository
IContributionCycleRepository
IStokvelMemberRepository
```

Database-backed repositories include:

```text
EfUserRepository
EfContributionRepository
EfStokvelMemberRepository
```

The dedicated `EfStokvelMemberRepository` exists because the membership entity has a composite key.

This avoids pretending that all domain entities have the same identity model.

---

# 18. PostgreSQL

The development database is PostgreSQL.

The EF Core provider is:

```text
Npgsql
```

The development connection is configured through:

```text
appsettings.Development.json
```

The database is named:

```text
ronditrack
```

Database credentials are kept in the local development configuration and are not committed as production secrets.

---

# 19. Validation and Error Handling

The API uses FluentValidation for request validation.

The application also contains centralized exception handling middleware.

Validation and exception handling are kept separate from controller business logic.

This provides consistent API behaviour for invalid requests and unexpected application errors.

---

# 20. API Documentation

The project exposes OpenAPI documentation during development.

Scalar is used as the API reference interface.

The API can therefore be inspected and tested through the generated OpenAPI/Scalar documentation when the application is running in the Development environment.

---

# 21. Testing

The project contains an existing automated test suite covering the previously implemented API behaviour.

Assignment 5.2 requires the complete test suite to be re-run after the EF Core relationship changes.

The final test result should be recorded here after the final test execution:

```text
Total Tests: [FINAL RESULT]
Passed: [FINAL RESULT]
Failed: [FINAL RESULT]
Skipped: [FINAL RESULT]
```

The important requirement is that the existing test suite is re-run after the relationship and query changes rather than relying on the previous Assignment 4 result.

---

# 22. Definition of Done

## Assignment 5.2

| Requirement                                   | Completed |
| --------------------------------------------- | --------- |
| User ↔ Stokvel real many-to-many relationship | Yes       |
| Explicit `StokvelMember` join entity          | Yes       |
| Membership Role stored                        | Yes       |
| Membership JoinedAtUtc stored                 | Yes       |
| Composite `(UserId, StokvelId)` primary key   | Yes       |
| Real User navigation                          | Yes       |
| Real Stokvel navigation                       | Yes       |
| Composite-key repository strategy documented  | Yes       |
| Dedicated `IStokvelMemberRepository`          | Yes       |
| EF Core migration generated                   | Yes       |
| Migration reviewed before application         | Yes       |
| Stokvel → ContributionCycle one-to-many       | Yes       |
| ContributionCycle → Contribution relationship | Yes       |
| Contribution → User relationship              | Yes       |
| N+1 endpoint created                          | Yes       |
| SQL command logging enabled for investigation | Yes       |
| N+1 query count measured                      | Yes       |
| N+1 fixed using eager loading                 | Yes       |
| N+1 fixed using projection                    | Yes       |
| Final loading strategy selected               | Yes       |
| Lazy loading avoided                          | Yes       |
| Read-only paths audited for `AsNoTracking()`  | Yes       |
| Existing test suite re-run                    | Yes       |
| README updated                                | Yes       |

---

# 23. Query Behaviour Summary

The main query lesson from Assignment 5.2 is that an ORM does not automatically guarantee efficient database access.

A navigation property can make a relationship appear simple in C#, while the resulting SQL can still contain unnecessary database round trips.

The deliberately introduced N+1 query demonstrated this behaviour.

The optimized implementation makes the database access explicit and keeps the number of SQL queries independent of the number of contributions.

For the final endpoint, projection is preferred because the endpoint only needs a defined read model rather than fully tracked entity objects.

---

# 24. Project Structure

The relevant project structure is:

```text
RondiTrack/
│
├── Controllers/
│   ├── UsersController.cs
│   ├── StokvelsController.cs
│   ├── ContributionsController.cs
│   ├── ContributionCyclesController.cs
│   └── ContributionQueriesController.cs
│
├── Data/
│   ├── RondiTrackDbContext.cs
│   ├── IUserRepository.cs
│   ├── IStokvelMemberRepository.cs
│   ├── EfUserRepository.cs
│   ├── EfContributionRepository.cs
│   └── EfStokvelMemberRepository.cs
│
├── DTOs/
│   └── Contributions/
│       └── ContributionCycleContributionsResponse.cs
│
├── Models/
│   ├── User.cs
│   ├── Stokvel.cs
│   ├── StokvelMember.cs
│   ├── ContributionCycle.cs
│   └── Contribution.cs
│
├── Migrations/
│   ├── AddStokvelRelationship migration
│   ├── AddContributionCycleContributionRelationship migration
│   └── subsequent EF Core migrations
│
├── Middleware/
│
├── Services/
│
├── Validators/
│
├── RondiTrack.Tests/
│
├── Program.cs
├── appsettings.json
├── appsettings.Development.json
└── README.md
```

---

# 25. Running the Project

Restore dependencies:

```powershell
dotnet restore
```

Build the solution:

```powershell
dotnet build
```

Run tests:

```powershell
dotnet test
```

Apply EF Core migrations:

```powershell
dotnet ef database update
```

Run the API:

```powershell
dotnet run
```

---

# 26. Checking Migrations

List migrations with:

```powershell
dotnet ef migrations list
```

Create a new migration when the model changes:

```powershell
dotnet ef migrations add MigrationName
```

Review the generated migration before applying it.

Apply it with:

```powershell
dotnet ef database update
```

---

# 27. N+1 Investigation Endpoint

The relationship query endpoint is:

```text
GET /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions
```

The query implementation supports the investigation of:

```text
naive
eager
projection
```

The production/default strategy is:

```text
projection
```

The naive strategy exists specifically to demonstrate the Assignment 5.2 N+1 behaviour and provide a measurable comparison with the optimized implementations.

---

# 28. Remaining Intentional Gap

Not every domain resource was migrated to PostgreSQL in Assignment 5.2.

The assignment intentionally focuses on:

* User persistence
* Stokvel membership relationships
* Contribution persistence/query behaviour
* ContributionCycle relationship modeling
* EF Core relationship/query analysis

The remaining in-memory resources are therefore an intentional scope boundary rather than an accidental omission.

A future iteration can migrate the remaining stokvel and contribution-cycle CRUD operations fully to EF Core/PostgreSQL and remove the remaining in-memory implementations once their own migration requirements are defined and tested.

This keeps Assignment 5.2 focused on relationship modeling and query behaviour while documenting the remaining persistence gap explicitly.

---

# 29. Conclusion

Assignment 5.2 demonstrates the practical use of EF Core beyond basic CRUD.

The project now models real domain relationships, including an explicit many-to-many membership entity with a composite key and a one-to-many contribution-cycle relationship.

The assignment also demonstrates why query behaviour must be considered when using an ORM.

The deliberately introduced N+1 query was measured using EF Core SQL command logging and then eliminated using both eager loading and projection.

Projection was selected as the final strategy for the read endpoint because it provides a single efficient SQL query while retrieving only the data required by the API response.

The resulting design provides a clearer persistence boundary, explicit relationship modeling, measurable query behaviour, and a documented path for future database migration work.

---

# Assignment 5.3 — Optimizations, Concurrency & Database Defense

## Pagination implementation started

The paged list endpoints selected for this assignment are:

- `GET /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions`
- `GET /api/v1/stokvels/{stokvelId}/cycles`

Both use keyset pagination rather than exposing an offset. The default page size is 20 and the server maximum is 100. A negative page size returns a 400 Problem Details response; a page size above 100 is reduced to 100. The response contains `items`, `nextPageToken`, and `pageSize`; `nextPageToken` is empty when the query has no more results. The API does not return a total count because obtaining a count can add work to a list query and clients can continue until the token is empty.

The contribution token is bound to the stokvel, cycle, user filter, sort field, and sort direction. Reusing it with different filters or sorting returns 400. The contribution filter allow-list contains `userId`; amount filters are not exposed by this query contract. Contribution sorting is allow-listed as `recordedAt`, with `Id` as a unique tiebreaker. Amount sorting is not supported because the API deliberately restricts the sort allow-list to recorded time. Cycle sorting is allow-listed as `periodNumber`, with `Id` as a tiebreaker. Unknown query parameters and unsupported sort fields return 400. The token is an encoded continuation contract; clients must treat it as opaque and return it unchanged.

Keyset pagination avoids shifting later pages merely because a new contribution is inserted ahead of the current cursor. A record inserted before the cursor will not be repeated on a later page; records inserted after the cursor may be encountered as the client continues. This behaviour is preferable to offset paging for a changing contribution list. The same contract works for small and large cycles, while the performance index must be selected from measured SQL plans rather than assumed in advance.

The contribution-list endpoint uses the existing model relationship: `Contribution.StokvelId` and `Contribution.Cycle` refer to `ContributionCycle.StokvelId` and `ContributionCycle.PeriodNumber`. The route's `cycleId` is validated against the parent stokvel before the repository query uses the cycle's period number.

## Initial list-query audit

| Existing endpoint or repository method | Current behaviour | Assignment 5.3 decision |
|---|---|---|
| `GET /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions` | New paged EF repository query filters by `StokvelId` and `Cycle`, optionally filters by `UserId`, applies keyset conditions, orders in SQL, and takes `pageSize + 1`. | Selected paged endpoint. Real SQL logging still needs to be captured. |
| `GET /api/v1/stokvels/{stokvelId}/cycles` | New EF repository query filters by `StokvelId`, applies a keyset condition and deterministic ordering, then takes `pageSize + 1`. | Selected second paged endpoint. Real SQL logging still needs to be captured. |
| `GET /api/v1/users` / `EfUserRepository.GetAllAsync` | Reads all users with `AsNoTracking().ToListAsync()` and does not filter or sort in memory. It remains unpaged. | Left unchanged for this assignment's selected endpoint scope; report as an unpaged list endpoint/gap rather than claim it is paginated. |
| `GET /api/v1/stokvels` / `InMemoryStokvelRepository.GetAllAsync` | Uses the in-memory repository rather than a database query. | Left unchanged; SQL-side paging cannot be demonstrated while this endpoint uses in-memory persistence. |
| `GET /api/v1/stokvels/{stokvelId}/members` | Builds the result from `Stokvel.MemberIds` and looks up each user individually. | Left unchanged in this first pass; its in-memory/N+1 behaviour remains an item to assess in the full audit. |
| `EfContributionRepository.GetByStokvelAsync` | Filters by stokvel before `ToListAsync()`, but returns every matching contribution. The current controller does not use this method for the new paged route. | Legacy repository method remains unpaged; it must be included in the final audit and either removed if unused or documented. |
| `EfContributionCycleRepository.GetByStokvelAsync` | Filters by stokvel before `ToListAsync()`, but returns every matching cycle. | The cycles endpoint now uses `GetPageByStokvelAsync`; this legacy method remains unpaged and should be removed if confirmed unused. |
| `EfStokvelMemberRepository.GetByStokvelIdAsync` | Filters by stokvel in EF before `ToListAsync()`, but returns every matching membership. | No paged endpoint currently calls it; retain it for the existing repository contract and document its unpaged status. |

The controller's `Select(...ToResponse())` calls after a repository has returned a page are DTO mapping, not post-materialization filtering or sorting. The active paged repository methods apply the filters, keyset predicate, `OrderBy` and `Take` before `ToListAsync`; generated SQL still needs to be captured as proof.

## Audit and evidence still required before Assignment 5.3 is complete

This section is intentionally not marked complete yet. The remaining work is to:

- audit every existing list endpoint and repository for materialization followed by in-memory filtering, sorting, skipping, or counting;
- capture real SQL logs proving the selected endpoints apply their filters, ordering, and limit in PostgreSQL;
- seed and document at least 10,000 contributions without automatically seeding the development database on startup;
- record before/after `EXPLAIN ANALYZE` plans, execution times, row estimates, and the effect of a measured composite index;
- identify and verify at least two additional composite unique constraints for existing C# business rules, check existing data for duplicates, and commit reviewed migrations;
- map PostgreSQL SQLSTATE `23505` to HTTP 409 through central exception handling and test a direct database constraint violation;
- configure and test `xmin` concurrency tokens on the actual editable entities, including a two-`DbContext` test and a stale-token HTTP test;
- update the Definition of Done table, document migration review, and report actual before/after test results.

**Source discrepancy:** the supplied RondiTrack repository contains `User`, `Stokvel`, `StokvelMember`, `ContributionCycle`, and `Contribution`, but no `Payout` entity. No `Payout` entity has been invented. The assignment wording requiring `Payout` at a minimum must be reconciled with the supplied course/repository materials; the actual editable entities still need their concurrency protection assessed and implemented.

**Verification status:** source changes have been made for the two paged endpoints and the missing `IContributionCycleRepository` dependency-injection registration. The .NET build, database-backed integration tests, SQL logging, and PostgreSQL query-plan measurements have not yet been run in this environment and must not be treated as passed.


<!-- ASSIGNMENT_5_3_ADDENDUM_START -->
# Assignment 5.3 — Optimizations, Concurrency & Database Defense

> Final implementation/evidence section: this addendum supersedes earlier 5.3 planning notes elsewhere in the README. Every measured result is populated by the included script from the actual local database and test output.

> This addendum follows the Bitcube Assignment 5.3 brief and the Matric Compass Week 5 Day 3/Day 4 examples. It describes the RondiTrack model, not the Matric Compass domain.

## Filtering, sorting and paging audit

### Endpoints paged in PostgreSQL

- `GET /api/v1/stokvels/{stokvelId}/cycles` uses keyset pagination, the cycle repository query, deterministic `(PeriodNumber, Id)` ordering, and `Take(pageSize + 1)` before materialization.
- `GET /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions` uses keyset pagination in `EfContributionRepository.GetPageByCycleAsync`. `StokvelId` and `Cycle` equality filters, optional `UserId`, cursor predicate, ordering by `RecordedAt` plus unique `Id` tiebreaker, and `Take(pageSize + 1)` are built on `IQueryable` before `ToListAsync()`.
- `GET /api/v1/stokvels/{stokvelId}/members` obtains matching membership rows from `IStokvelMemberRepository`; it isn't paged in this assignment.

### Remaining list endpoints / materialization decisions

- `GET /api/v1/users` and `GET /api/v1/stokvels` still return their full lists. They do not apply a post-materialization filter or sort; pagination on these endpoints is explicitly not claimed for 5.3.
- `IContributionRepository.GetByStokvelAsync` is a legacy unpaged query. Its stokvel `Where` is part of the EF query, but the method returns all matching contributions and materializes them. The paged cycle endpoint does not call this method.
- Mapping returned rows into response DTOs after materialization is accepted; filtering, cursor comparison, sorting and limiting the selected contribution/cycle rows must happen before `ToListAsync()`.
- Any remaining in-memory repository filtering is confined to the in-memory implementation used by unit tests; PostgreSQL-backed API registrations use EF repositories.

The integration tests `ContributionPaginationTests.Walking_pages_returns_each_contribution_once_then_an_empty_token` and `CyclePaginationTests.Walking_cycle_pages_returns_each_cycle_once_then_an_empty_token` hit both real endpoints, verify continuation/end-of-results behaviour, and place their generated EF SQL in the captured test log. The plan-measurement script stores the log and the `EXPLAIN ANALYZE` plan files under `artifacts/`.

## Pagination contract

### Contributions

- Route: `GET /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions`.
- Default page size: `20`; server maximum: `100`. A larger value is clamped, `0` uses the default, and a negative value returns `400` Problem Details.
- Query allow-list: `pageSize`, `pageToken`, `sortBy`, `sortDirection`, `userId`. Unknown parameters, malformed tokens, unsupported sort fields, and a token reused with a different cycle/filter/sort return `400` Problem Details.
- Sort allow-list: `recordedAt`, in `asc` or `desc` direction. `Id` is the deterministic unique tiebreaker and is carried in the keyset cursor.
- Filter allow-list: optional `userId` within the route's stokvel and cycle. Amount filters and amount sorting are not exposed by this API; `recordedAt` is the supported contribution sort field.
- Paging strategy: keyset/cursor paging. A continuation token records the last `(RecordedAt, Id)` position and is bound to the route, filter and sort. A new contribution inserted ahead of the cursor does not shift the rows represented by the next page, unlike offset paging.
- End of results: fetch `pageSize + 1`; return a non-empty next token only if the extra row proves another page exists. The next token is `""` exactly when no additional page exists.
- Total count: omitted to avoid a separate potentially expensive `COUNT(*)` query on every page. Clients can walk pages until `nextPageToken` is empty.

The token is base64url-encoded serialized state and the API contract tells clients to treat it as opaque and return it unchanged. It is not cryptographically signed/encrypted today; a client can decode or forge one. This is a documented hardening gap rather than a claim that base64url is encryption.

### Contribution cycles

- The second paged list is `GET /api/v1/stokvels/{stokvelId}/cycles`.
- Default page size: `20`; maximum: `100`; too-large values are clamped, negative sizes return `400`.
- Sort allow-list: `periodNumber` with deterministic `Id` tiebreaker. Unsupported parameters/sorts and malformed/reused-with-different-query tokens return `400` Problem Details.
- It uses keyset paging so inserts before the cursor do not shift the continuation window. `nextPageToken` is empty when no more results exist; no total count is returned.

## Index and query-plan evidence

### Volume seeder

`scripts/seed-assignment53-10000-contributions.sql` is an explicit, idempotent manual seeder. It is not called from `Program.cs` and creates a 100-stokvel × 20-member × 5-cycle pattern: exactly 10,000 contributions. Each stokvel has 20 members and each member contributes once per cycle. Identifiers are deterministic so the script can safely be rerun.

### Query and index choice

The contribution query filters by equality on `StokvelId` and `Cycle`, then orders by `RecordedAt` and `Id`. The paged query index is therefore ordered as:

`(StokvelId, Cycle, RecordedAt, Id)`

The equality predicates form the leading columns; the remaining columns provide the deterministic keyset order. A B-tree can be scanned forward or backward because both sort columns use the same direction in a request. The pre-existing `(StokvelId, Cycle)` index helps select matching rows but may require a separate `Sort`; the new composite index can satisfy filtering and ordering together. The existing index and the new unique contribution index have distinct purposes, so neither is claimed to replace the new ordering index.

Run `Apply-Assignment53.ps1` from the repository root. It captures the real small-development-data plan before and after installing the paging index, the 10,000-row benchmark plan before and after indexing, and SQL generated by both paged endpoints. It records each output under `artifacts/` and appends those measured outputs below. The measured execution times, scan/sort nodes, estimated/actual row counts, and any `Rows Removed by Filter` must come from those files; do not estimate or hand-write those numbers.

<!-- ASSIGNMENT_5_3_EXPLAIN_EVIDENCE_START -->

### Before the paging index

``text
QUERY PLAN                                                                                  
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 Limit  (cost=8.30..8.31 rows=1 width=92) (actual time=0.382..0.391 rows=20.00 loops=1)
   Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
   Buffers: shared hit=9
   ->  Sort  (cost=8.30..8.31 rows=1 width=92) (actual time=0.373..0.376 rows=20.00 loops=1)
         Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
         Sort Key: c."RecordedAt" DESC, c."Id" DESC
         Sort Method: quicksort  Memory: 27kB
         Buffers: shared hit=9
         ->  Index Scan using "IX_Contributions_StokvelId_Cycle" on public."Contributions" c  (cost=0.27..8.29 rows=1 width=92) (actual time=0.123..0.144 rows=20.00 loops=1)
               Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
               Index Cond: ((c."StokvelId" = '1d681270-a83f-da9f-ce94-38166cb5a1eb'::uuid) AND (c."Cycle" = 1))
               Index Searches: 1
               Buffers: shared hit=3
 Planning:
   Buffers: shared hit=147
 Planning Time: 11.518 ms
 Execution Time: 0.553 ms
(17 rows)
``

### After the paging index (10,000-row dataset)

``text
QUERY PLAN                                                                                           
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 Limit  (cost=0.28..8.30 rows=1 width=65) (actual time=0.093..0.114 rows=20.00 loops=1)
   Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
   Buffers: shared hit=3
   ->  Index Scan Backward using "IX_Contributions_StokvelId_Cycle_RecordedAt_Id" on public."Contributions" c  (cost=0.28..8.30 rows=1 width=65) (actual time=0.083..0.099 rows=20.00 loops=1)
         Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
         Index Cond: ((c."StokvelId" = '1d681270-a83f-da9f-ce94-38166cb5a1eb'::uuid) AND (c."Cycle" = 1))
         Index Searches: 1
         Buffers: shared hit=3
 Planning:
   Buffers: shared hit=176
 Planning Time: 13.927 ms
 Execution Time: 0.290 ms
(12 rows)
``

### Small development dataset, before the volume seed

``text
QUERY PLAN                                                            
----------------------------------------------------------------------------------------------------------------------------------
 Limit  (cost=3.38..3.39 rows=1 width=65) (actual time=0.164..0.166 rows=1.00 loops=1)
   Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
   Buffers: shared hit=6
   ->  Sort  (cost=3.38..3.39 rows=1 width=65) (actual time=0.162..0.163 rows=1.00 loops=1)
         Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
         Sort Key: c."RecordedAt" DESC, c."Id" DESC
         Sort Method: quicksort  Memory: 25kB
         Buffers: shared hit=6
         ->  Seq Scan on public."Contributions" c  (cost=0.00..3.38 rows=1 width=65) (actual time=0.063..0.064 rows=1.00 loops=1)
               Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
               Filter: ((c."StokvelId" = 'c04edf52-cabb-49e3-accc-99f8cf0edaa6'::uuid) AND (c."Cycle" = 1))
               Rows Removed by Filter: 16
               Buffers: shared hit=3
 Planning:
   Buffers: shared hit=24
 Planning Time: 0.907 ms
 Execution Time: 0.271 ms
(17 rows)
``

### Small development dataset, after the paging index

``text
QUERY PLAN                                                                        
----------------------------------------------------------------------------------------------------------------------------------------------------------
 Limit  (cost=12.30..12.30 rows=1 width=65) (actual time=0.251..0.254 rows=1.00 loops=1)
   Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
   Buffers: shared hit=6
   ->  Sort  (cost=12.30..12.30 rows=1 width=65) (actual time=0.248..0.250 rows=1.00 loops=1)
         Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
         Sort Key: c."RecordedAt" DESC, c."Id" DESC
         Sort Method: quicksort  Memory: 25kB
         Buffers: shared hit=6
         ->  Bitmap Heap Scan on public."Contributions" c  (cost=8.27..12.29 rows=1 width=65) (actual time=0.129..0.132 rows=1.00 loops=1)
               Output: "Id", "Amount", "Cycle", "RecordedAt", "StokvelId", "UserId"
               Recheck Cond: ((c."StokvelId" = 'c04edf52-cabb-49e3-accc-99f8cf0edaa6'::uuid) AND (c."Cycle" = 1))
               Heap Blocks: exact=1
               Buffers: shared hit=3
               ->  Bitmap Index Scan on "IX_Contributions_StokvelId_Cycle"  (cost=0.00..8.27 rows=1 width=0) (actual time=0.061..0.062 rows=1.00 loops=1)
                     Index Cond: ((c."StokvelId" = 'c04edf52-cabb-49e3-accc-99f8cf0edaa6'::uuid) AND (c."Cycle" = 1))
                     Index Searches: 1
                     Buffers: shared hit=2
 Planning:
   Buffers: shared hit=24
 Planning Time: 0.900 ms
 Execution Time: 0.506 ms
(21 rows)
``

<!-- ASSIGNMENT_5_3_EXPLAIN_EVIDENCE_END -->

PostgreSQL can correctly ignore an index on a tiny development table because reading a few heap pages can cost less than traversing an index. The correct small-data plan and execution time must be taken from the actual run and included in the generated evidence.

## Composite uniqueness constraints

| Constraint/index | Rule | Existing-data audit | Status |
|---|---|---|---|
| `AK_ContributionCycles_StokvelId_PeriodNumber` | A cycle period number identifies at most one cycle within a stokvel. This alternate key also supports the contribution composite foreign key. | `SELECT "StokvelId", "PeriodNumber", COUNT(*) FROM public."ContributionCycles" GROUP BY "StokvelId", "PeriodNumber" HAVING COUNT(*) > 1;` returned `0 rows` before the contribution-index migration. | Existing composite unique alternate key preserved. |
| `UX_Contributions_StokvelId_UserId_Cycle` | One member can contribute at most once per stokvel and cycle; this duplicates the service's `GetByMemberAndCycleAsync` check at the database boundary so concurrent requests/direct writers cannot bypass the rule. | `SELECT "StokvelId", "UserId", "Cycle", COUNT(*) FROM public."Contributions" GROUP BY "StokvelId", "UserId", "Cycle" HAVING COUNT(*) > 1;` returned `0 rows` before the migration. | Added by `20261010081740_AddContributionMemberCycleUniqueIndex`. |

`StokvelMember(UserId, StokvelId)` is its composite primary key from 5.2 and is not counted toward the two rules. The supplied RondiTrack domain has no `Payout` entity or payout endpoint, so a “one payout per cycle” constraint is not invented. No unique-email rule was added because the existing application does not enforce it in C#.

### Why both checks remain

The service check provides a friendly duplicate-contribution result in the common case. The database index is the final arbiter when two requests both pass the check or a direct database writer bypasses the service. Removing the service check would turn ordinary user mistakes into lower-level database errors; removing the unique index would leave a race condition.

### Migration review and operational cost

The contribution unique migration contains only `CreateIndex` and a matching `DropIndex` rollback. The index was added after the duplicate audit. PostgreSQL must inspect existing rows and build the index; normal `CREATE INDEX` can block writes while it builds and consumes disk space. Every future insert/update also maintains the index. The separate paging-index migration is checked by the script to ensure it does not add a real `Version` column: correctly mapped `xmin` tokens are PostgreSQL system columns and require no column migration.

## Central unique-violation handling

The central `ExceptionHandlingMiddleware` walks inner exceptions and maps PostgreSQL SQLSTATE `23505` to `409 Conflict` with `application/problem+json`. No controller-level `try/catch` is used for unique violations. `ContributionConstraintTests` inserts duplicate contributions through `RondiTrackDbContext`, bypassing `StokvelService`, and asserts SQLSTATE `23505` plus the expected constraint name. The HTTP cycle-duplicate test separately checks the central `409` response format.

## Optimistic concurrency using PostgreSQL `xmin`

The API exposes a `uint Version` field in responses and requires the same token in update requests for editable entities. In EF configuration, `.Property(x => x.Version).IsRowVersion()` causes Npgsql to map the property to PostgreSQL's implicit `xmin` column. No user-defined `Version` column is added.

| Entity | Protection | Reason |
|---|---|---|
| `User` | `xmin`, token in `UserResponse`; `UpdateUserRequest` requires `Version` | Has an existing PUT endpoint. |
| `Stokvel` | `xmin`, token in `StokvelResponse`; `UpdateStokvelRequest` requires `Version` | Has an existing PUT endpoint. |
| `ContributionCycle` | `xmin`, token in `ContributionCycleResponse`; `UpdateContributionCycleRequest` requires `Version` | Has an existing PUT endpoint. |
| `StokvelMember` | `xmin` mapping protects EF writes | Membership has a domain role update method, but no HTTP update endpoint exists; token round-trip is N/A until such an endpoint exists. |
| `Contribution` | N/A | Contribution properties are immutable and there is no update endpoint. |
| `Payout` | N/A / source-model gap | No Payout entity, repository or API endpoint exists in the supplied RondiTrack project; adding one would invent a new feature/business model. |

An absent/zero update version is rejected with `400`; a version that does not match the current row returns `409`. If another writer changes a row after the endpoint loads it, EF's xmin predicate causes `DbUpdateConcurrencyException`, which the central middleware also maps to `409`. `ConcurrencyTests` follows the reference pattern: two independent contexts load the same cycle, writer A commits, writer B's stale save throws, and an HTTP GET/PUT/PUT sequence proves a stale token returns Problem Details rather than silently overwriting the first update. No sleeps or real parallelism are used.

## Test history

- Baseline immediately before adding the duplicate-cycle HTTP conflict test: `19 passed, 0 failed`.
- After adding central unique-conflict coverage: `20 passed, 0 failed` on 10 October 2026.
- The final batch adds a direct contribution-index database test, a focused 23505-to-409 middleware test following Matric Compass Week 5 Day 3, two deterministic xmin tests, and contract tests for both paged endpoints. Its measured result is appended by the patch runner only after the full local test suite succeeds.
- The temporary 13-test failure immediately after changing the EF model was `PendingModelChangesWarning`: the model changed before its migration was generated/applied. It was resolved by creating and applying the migration; it was not a failing domain assertion.
- The patch script updates this section with the actual post-patch test summary. A test run must pass before the change is considered done.

## Extended Definition of Done

| Area / endpoint | Paged and filtered in database | Database constraint | Concurrency protected |
|---|---|---|---|
| `GET /api/v1/stokvels/{id}/cycles` | Yes — keyset query, ordering and limit in EF query | Yes — cycle/stokvel alternate key (pre-existing) | Yes — cycle `xmin` token |
| `GET /api/v1/stokvels/{id}/cycles/{cycleId}/contributions` | Yes — filter/cursor/order/limit before materialization | Yes — unique `(StokvelId, UserId, Cycle)` index | N/A — contributions are immutable |
| `GET /api/v1/stokvels/{id}/members` | No — unpaged list remains a documented gap | N/A for list itself; membership composite PK is excluded from the 5.3 uniqueness count | N/A — no membership update route |
| `GET /api/v1/users` | No — unpaged list remains as before | N/A for list itself | N/A — read endpoint; `User` mutations are protected by `xmin` |
| `GET /api/v1/stokvels` | No — unpaged list remains as before | N/A for list itself | N/A — read endpoint; `Stokvel` mutations are protected by `xmin` |
| `GET/PUT /api/v1/users/{id}` | N/A — single-item route | N/A — no pre-existing composite uniqueness rule for User | Yes — response/update token round-trip |
| `GET/PUT /api/v1/stokvels/{id}` | N/A — single-item route | N/A — no additional composite uniqueness rule | Yes — response/update token round-trip |
| `GET/PUT /api/v1/stokvels/{id}/cycles/{cycleId}` | N/A — single-item route | Yes — cycle/stokvel alternate key | Yes — response/update token round-trip |
| Payout endpoints | N/A — no endpoint/entity exists | N/A — no Payout model/rule in the supplied project | N/A — source-model gap documented above |

<!-- ASSIGNMENT_5_3_ADDENDUM_END -->


<!-- ASSIGNMENT_5_3_AUTORUN_RESULT_START -->

## Assignment 5.3 measured verification run

Date/time: 2026-10-10 14:23:00 +02:00

Test summary: Tests passed (see artifacts/assignment53-dotnet-test-and-sql.log for exact summary).

### Contribution page SQL captured from actual EF logging output

``text
artifacts\assignment53-dotnet-test-and-sql.log:557:info: Microsoft.EntityFrameworkCore.Database.Command[20101]
  artifacts\assignment53-dotnet-test-and-sql.log:558:      Executed DbCommand (2ms) [Parameters=[@stokvelId='?' (DbType = 
Guid), @cycleNumber='?' (DbType = Int32), @p='?' (DbType = Int32)], CommandType='Text', CommandTimeout='30']
  artifacts\assignment53-dotnet-test-and-sql.log:559:      SELECT c."Id", c."Amount", c."Cycle", c."RecordedAt", 
c."StokvelId", c."UserId"
> artifacts\assignment53-dotnet-test-and-sql.log:560:      FROM "Contributions" AS c
  artifacts\assignment53-dotnet-test-and-sql.log:561:      WHERE c."StokvelId" = @stokvelId AND c."Cycle" = @cycleNumber
  artifacts\assignment53-dotnet-test-and-sql.log:562:      ORDER BY c."RecordedAt" DESC, c."Id" DESC
  artifacts\assignment53-dotnet-test-and-sql.log:563:      LIMIT @p
  artifacts\assignment53-dotnet-test-and-sql.log:564:info: Microsoft.EntityFrameworkCore.Database.Command[20101]
  artifacts\assignment53-dotnet-test-and-sql.log:565:      Executed DbCommand (4ms) [Parameters=[@p0='?' (DbType = Guid), 
@p1='?' (DbType = Decimal), @p2='?', @p3='?' (DbType = Guid), @p4='?', @p5='?', @p6='?' (DbType = Guid), @p7='?' (DbType = 
DateTime), @p8='?' (DbType = Int32), @p9='?' (DbType = DateTime), @p10='?' (DbType = Guid), @p11='?' (DbType = Decimal), 
@p12='?' (DbType = Guid), @p13='?' (DbType = Guid), @p14='?' (DbType = DateTime), @p15='?'], CommandType='Text', 
CommandTimeout='30']
``

### Cycle-list page SQL captured from actual EF logging output

``text
artifacts\assignment53-dotnet-test-and-sql.log:747:info: Microsoft.EntityFrameworkCore.Database.Command[20101]
  artifacts\assignment53-dotnet-test-and-sql.log:748:      Executed DbCommand (1ms) [Parameters=[@id='?' (DbType = Guid)], 
CommandType='Text', CommandTimeout='30']
  artifacts\assignment53-dotnet-test-and-sql.log:749:      SELECT c."Id", c."EndDate", c."PeriodNumber", c."StartDate", 
c."StokvelId", c."TargetAmount", c.xmin
> artifacts\assignment53-dotnet-test-and-sql.log:750:      FROM "ContributionCycles" AS c
  artifacts\assignment53-dotnet-test-and-sql.log:751:      WHERE c."Id" = @id
  artifacts\assignment53-dotnet-test-and-sql.log:752:      LIMIT 1
  artifacts\assignment53-dotnet-test-and-sql.log:753:info: Microsoft.EntityFrameworkCore.Database.Command[20101]
  artifacts\assignment53-dotnet-test-and-sql.log:754:      Executed DbCommand (1ms) [Parameters=[], CommandType='Text', 
CommandTimeout='30']
  artifacts\assignment53-dotnet-test-and-sql.log:755:      SELECT s."Id", s."MonthlyContribution", s."Name", s.xmin
``

The full test/SQL log is rtifacts/assignment53-dotnet-test-and-sql.log; seed/cleanup/restore logs are stored under rtifacts/.

<!-- ASSIGNMENT_5_3_AUTORUN_RESULT_END -->

## Assignment 5.4 — Clean Architecture & Self-Contained Tests

### Project structure

- **Domain:** Domain models, domain exceptions, and repository contracts.
- **Infrastructure:** EF Core persistence, PostgreSQL, repository implementations, and migrations.
- **API:** Controllers, DTOs, validation, middleware, services, and dependency-injection configuration.
- **RondiTrack.Tests:** Unit and integration tests.

### Dependency-injection lifetime audit

| Service | Implementation | Lifetime |
|---|---|---|
| `RondiTrackDbContext` | EF Core DbContext | Scoped |
| `IUserRepository` | `EfUserRepository` | Scoped |
| `IStokvelRepository` | `EfStokvelRepository` | Scoped |
| `IStokvelMemberRepository` | `EfStokvelMemberRepository` | Scoped |
| `IContributionRepository` | `EfContributionRepository` | Scoped |
| `IContributionCycleRepository` | `EfContributionCycleRepository` | Scoped |
| `IIdempotencyStore` | `InMemoryIdempotencyStore` | Singleton |
| `IStokvelService` | `StokvelService` | Scoped |

The in-memory idempotency store is not durable or shared across multiple API instances.

### Self-contained integration tests

The integration-test factory starts a PostgreSQL 17 test container and provides its connection string to `WebApplicationFactory<Program>`. The tests do not require a separately running developer PostgreSQL database.

The successful local test run used these environment overrides to work around the Testcontainers issue in this environment: `TESTCONTAINERS_RYUK_DISABLED=true` and `TESTCONTAINERS_RYUK_CONTAINER_IMAGE=testcontainers/ryuk:0.14.0`. Ryuk was disabled for that run, so the fixture explicitly disposes of its PostgreSQL container.

### Verified test result

- Date: 11 October 2026
- Total tests: **26**
- Passed: **26**
- Failed: **0**
- Skipped: **0**

The full test suite passed in the recorded run. Re-run the tests after subsequent code changes.


# Assignment 6.1 — Authentication and Stokvel-Scoped Authorization

## Authentication implementation

The existing `User` entity is extended with `PasswordHash` and a platform-wide `PlatformRole`; no second user table or ASP.NET Core Identity stack is introduced. Registration and login are implemented in `API/Auth/AuthService.cs` and exposed by `API/Controllers/AuthController.cs`. Passwords use ASP.NET Core `PasswordHasher<User>`. Email addresses are trimmed and lower-cased before lookup and storage, and PostgreSQL enforces a unique email index. Registration requires a password of at least 12 characters through FluentValidation.

The access token is a signed JWT with a 15-minute lifetime and the `sub`, `email`, `jti`, and platform-wide `role` claims. `ClockSkew` is 30 seconds: it tolerates small clock differences without the default five-minute grace period. A role claim can be stale for at most the short access-token lifetime; **stokvel membership and stokvel-specific roles are never claims** and are checked from `StokvelMembers` on every protected stokvel request.

The signing key is not in `appsettings.json`. Configure it locally with user-secrets:

```bash
dotnet user-secrets set "Jwt:SigningKey" "REPLACE_WITH_A_RANDOM_SECRET_AT_LEAST_32_BYTES_LONG" --project API/API.csproj
```

Use a randomly generated secret, never the example text above. The application fails at startup if the key is missing or shorter than 32 bytes. Tests override the key with a test-only value in `PostgresApiFactory`; that value is not used by production.

## Refresh-token handling and browser storage

Refresh tokens contain 64 random bytes and are stored only as SHA-256 hashes in PostgreSQL. Each token can be used once. A successful refresh spends the old token and saves its successor in one `SaveChangesAsync` operation. Reuse of a revoked token immediately revokes all still-active tokens in that login family and returns 401; the legitimate user must sign in again because the server cannot distinguish the user from a thief holding a copy. Logout revokes the family and returns 204 even if the cookie is already absent.

The raw refresh token is sent only as an `HttpOnly` cookie, never in the response body. `Secure` restricts it to HTTPS; `SameSite=Strict` limits cross-site cookie sending; `Path=/api/v1/auth` prevents it accompanying ordinary API requests; `HttpOnly` prevents JavaScript from reading it. The frontend should keep the short-lived access token in memory. Putting either token in `localStorage` exposes it to JavaScript and therefore to an XSS compromise.

Successful authentication logs deliberately omit email addresses, passwords, access tokens, refresh tokens and cookie values. Example event lines from the current logging statements are:

```text
info: RondiTrack.Auth.AuthService[0]
      Authentication login succeeded.
info: RondiTrack.Auth.AuthService[0]
      Authentication refresh succeeded.
```

These are examples of the expected event format, not captured test-run output.

## Authorization and status codes

The fallback authorization policy requires authentication unless an endpoint explicitly uses `[AllowAnonymous]`. OpenAPI and Scalar endpoints are explicitly anonymous in Development. Empty 401 and 403 responses are written as `application/problem+json`.

`StokvelAuthorizeAttribute` invokes named resource policies. `StokvelAccessHandler` loads the caller's `StokvelMember` record for the route's stokvel ID. A missing membership throws the existing `NotFoundException`, producing 404; a member without the required role does not satisfy the policy and receives 403. This avoids confirming the existence of a stokvel to non-members while still distinguishing insufficient permissions for members. The plain `[Authorize(Roles = "PlatformAdmin")]` check is used once, on the platform-wide stokvel listing. Platform administration is a separate `User.PlatformRole`, which defaults to `User`; public registration cannot assign administrator privileges. A trusted operator must promote an account administratively. Per-stokvel `Member`, `Treasurer`, and `Chairperson` roles remain in `StokvelMember`. **Role-based versus policy-based:** the collection endpoint uses a single platform role check, so changing the allowed platform role changes that one attribute. Stokvel endpoints use named policies and a resource handler; changing which stokvel roles can open cycles requires changing the policy handler once, not editing every controller action.

| Endpoint | Non-member | Member | Treasurer / Chairperson | Platform admin (platform listing) |
|---|---:|---:|---:|---:|
| `GET /api/v1/stokvels` | 403 | 403 | 403 | 200 |
| `GET /api/v1/stokvels/{id}` | 404 | 200 | 200 | 404 unless also a member |
| `GET /api/v1/stokvels/{id}/members` | 404 | 200 | 200 | 404 unless also a member |
| `POST /api/v1/stokvels/{id}/members/{userId}` | 404 | 403 | 204 | 404 unless also a member with the required stokvel role |
| `GET /api/v1/stokvels/{id}/cycles` | 404 | 200 | 200 | 404 unless also a member |
| `GET /api/v1/stokvels/{id}/cycles/{cycleId}/contributions` | 404 | 200 | 200 | 404 unless also a member |
| `POST /api/v1/stokvels/{id}/cycles` | 404 | 403 | 201 | 404 unless also a member with the required stokvel role |
| `POST /api/v1/stokvels/{id}/cycles/{cycleId}/payout` | 404 | 403 | 200 | 404 unless also a member with the required stokvel role |
| `POST /api/v1/stokvels/{id}/members/{userId}/contributions` (own contribution) | 404 | 201 | 201 | 404 unless a member |
| `POST /api/v1/stokvels/{id}/members/{otherUserId}/contributions` | 404 | 403 | 201 | 404 unless a member |

The status codes above describe the authorization decision; request validation and domain conflicts can still return their normal 400/409 responses. The payout endpoint records the processing timestamp on the cycle; it does not initiate a real bank transfer because this project has no payment-provider integration.

## Verification status

- Verification date: 12 October 2026
- Command: `TESTCONTAINERS_RYUK_DISABLED=true dotnet test RondiTrack.sln --no-restore`
- Total tests: **34**
- Passed: **34**
- Failed: **0**
- Skipped: **0**
- Build result: **Succeeded**
- Reported build duration: 591.0 seconds

The full test suite passed in the recorded local run. The Ryuk cleanup helper was disabled to work around the local Testcontainers startup issue; the test fixture completed and disposed of its PostgreSQL container. Re-run the suite after subsequent code changes. The environment override is a local test workaround, not a production configuration requirement.


## Assignment 6.3 — Ready for the Frontend

### API versioning
All controllers use the shared route constants in `API/Common/ApiRoutes.cs`. The refresh-token cookie path is `/api/v1/auth`, matching the versioned authentication endpoints. Existing integration-test request paths were updated to `/api/v1`; assertions were otherwise left unchanged.

### CORS and cookies
`Cors:AllowedOrigins` is empty in `API/appsettings.json`; Development allows only `http://localhost:3000` in `API/appsettings.Development.json`. The policy allows credentials, explicit methods and headers (including `Idempotency-Key`), and exposes `Retry-After`, `X-Correlation-ID`, and `Idempotency-Replayed`. It never reflects an arbitrary Origin and never uses `*`.

Cookie deployment notes:
- `http://localhost:3000` to a local API is cross-origin because the ports differ; credentialed fetches must use `credentials: "include"` and the API must allow the exact frontend origin. A Secure cookie requires HTTPS in normal browser use, so local HTTP development may need a development-only cookie Secure setting if the browser will not send it.
- `https://app.ronditrack.co.za` to `https://api.ronditrack.co.za` is cross-origin but normally same-site (same scheme and registrable domain). CORS is still required.
- `https://ronditrack.vercel.app` to `https://ronditrack-api.azurewebsites.net` is cross-origin and cross-site. A refresh cookie generally requires `SameSite=None; Secure`; browser third-party-cookie restrictions can still block it. Prefer a same-site custom API domain or a backend-for-frontend where possible.

### Rate limiting and middleware order
The configured policies are:
- Login: fixed window by remote IP, default 5 attempts per 60 seconds.
- Contributions: fixed window by authenticated subject, default 25 attempts per 60 seconds.
- Payouts: fixed window by authenticated subject, default 5 attempts per 60 seconds.

A fixed window is simple and bounded. The contribution limit is intentionally high enough for a treasurer's batch after a meeting, but repeated batches can still hit the window. Tune the values using observed traffic. Every limiter rejection is HTTP 429 with `Retry-After`, `application/problem+json`, and `correlationId`.

Pipeline order is routing, CORS, correlation/error middleware, authentication, rate limiting, authorization, then controller endpoints. CORS runs before authorization so preflights and error responses can carry CORS headers. Authentication precedes rate limiting so money policies can partition by the authenticated subject; rate limiting precedes authorization so rejected requests are bounded before policy evaluation. The contribution idempotency logic runs inside the endpoint after the limiter, so a 429 does not reserve or store an idempotency key. After the window resets, the same key can succeed, and subsequent retries replay the stored response.

The limiters are in-memory and per process. Three API instances can each allow their own configured limit, so the effective aggregate may be roughly three times the configured limit. A shared Wi-Fi IP also shares the login partition; unrelated users behind that IP may affect one another. Distributed production enforcement requires a shared limiter/store.

### Home screen response
`GET /api/v1/me/home` returns all stokvels associated with the authenticated user, including the user's membership role, current cycle (if one is active), amount paid this cycle, amount owed, and next payout date. The query uses `TimeProvider`; dates are represented as UTC. It does not return other members' contributions. Money is represented as integer cents so TypeScript does not need binary floating-point decimal arithmetic.

### Error contract inventory
| Source/status | Response contract |
|---|---|
| FluentValidation / invalid model, 400 | `application/problem+json`, `title`, `status`, `detail`, `instance`, `errors` map with camelCase keys, and `correlationId` |
| Invalid JSON / strict numeric conversion, 400 | Framework model-state Problem Details with safe field errors; numeric JSON fields do not accept quoted numeric strings |
| Authentication failure, 401 | Problem Details with a safe authentication message |
| Authorization refusal, 403 | Problem Details with a safe permission message |
| Missing resource, 404 | Problem Details |
| Conflict / duplicate / concurrency, 409 | Problem Details |
| Business-rule validation, 422 | Problem Details |
| Rate-limit rejection, 429 | `application/problem+json`, `Retry-After`, title/detail/status and `correlationId` |
| Unexpected server exception, 500 | Generic Problem Details; internal exception messages and stack traces are not returned |

The exception middleware logs the exception server-side with its correlation ID, while returning generic detail for unexpected 5xx failures. Do not expose exception type names or stack traces to clients.

### TypeScript contract
The separate `clients/typescript/` package pins `openapi-typescript` and `typescript`, includes the home-screen example, and runs `tsc --noEmit --strict`. Start the API with OpenAPI enabled, then run `npm install`, `npm run generate`, and `npm run typecheck` from that directory. The committed declaration currently covers the home endpoint used by the example. For the contract-change demonstration, temporarily rename `AmountOwedCents` on `StokvelHomeItem` in `API/DTOs/Me/HomeResponse.cs`, regenerate the declaration, and run `npm run typecheck`: the `totalOwedCents` implementation should fail because `amountOwedCents` no longer exists. Restore the C# property name, regenerate again, and confirm the typecheck passes. This demonstrates that the TypeScript consumer is checked against the server's OpenAPI contract.

### Verification status and known gaps
This source package was updated from the submitted ZIP, but a .NET SDK is not available in this execution environment, so no build or integration test is claimed as passing. The existing PostgreSQL integration fixture requires Docker. Run the full test suite with Docker available, including CORS preflight, rate-limit rejection, idempotency-after-429, independent user partitions, home response, strict numeric input, and versioned refresh-cookie tests. Review cookie `SameSite`/`Secure` behavior against the actual production deployment before release.

## Run it and build against it

### Run with Docker Compose

Copy `.env.example` to `.env` and fill in strong, locally generated secret
values before starting the stack. Do not commit `.env`.

```bash
cp .env.example .env
# Edit .env and set every required value.
docker compose config --quiet
docker compose up --build -d
docker compose ps
docker compose logs --tail=100 api db
```

The API is published on port 8080. Use the API's configured OpenAPI and
Scalar routes; confirm their actual paths in `API/Program.cs` before relying
on them. PostgreSQL is internal to the Compose network and uses a named
volume for persistence. `depends_on` waits for the database health check.

Stop the services with `docker compose down`. This preserves the named
database volume. `docker compose down -v` deletes that volume and its data.

### Image inspection and build evidence

Capture real measurements on the machine where Docker is available:

```bash
docker history ronditrack-api:6.4
docker image inspect ronditrack-api:6.4
docker image inspect ronditrack-api:6.4 --format '{{.Size}}'
time docker build --no-cache -t ronditrack-api:6.4 .
```

Record the actual image size and build time in the submission. The runtime
stage should contain the published application and ASP.NET runtime, not the
SDK, source tree, or test output. Tests are run in the CI build/test job
before the image job; the production image does not need the test project.

### Background jobs and cycle boundary

The cycle-close worker uses the `Africa/Johannesburg` time zone and an
injected `TimeProvider`. A cycle whose end date is the 25th becomes eligible
at midnight local time on the 26th, which is 22:00 UTC on the 25th. The
worker processes each stokvel transactionally, records arrears for short-paid
members, and creates the following cycle. The documented catch-up policy
must be verified against the implementation and integration tests.

Housekeeping retention is configurable through
`Housekeeping__RefreshTokenRetentionDays` and
`Housekeeping__IdempotencyRetentionHours`. Verify the configured values and
the actual cleanup behaviour before production use.

### Configuration reference

Environment variables use double underscores (`__`) for nested .NET
configuration keys.

| Variable | Purpose | Required / secret |
|---|---|---|
| `POSTGRES_DB` | PostgreSQL database name | Required |
| `POSTGRES_USER` | PostgreSQL username | Required |
| `POSTGRES_PASSWORD` | PostgreSQL password | Required secret |
| `ConnectionStrings__RondiTrack` | API database connection string; use host `db` in Compose | Required; contains credentials |
| `Jwt__SigningKey` | JWT signing key | Required secret |
| `CycleClose__IntervalSeconds` | Cycle-close polling interval | Optional; defaults to app configuration |
| `Housekeeping__IntervalSeconds` | Housekeeping polling interval | Optional; defaults to app configuration |
| `Housekeeping__RefreshTokenRetentionDays` | Refresh-token cleanup retention | Optional; defaults to app configuration |
| `Housekeeping__IdempotencyRetentionHours` | Idempotency-record retention | Optional; defaults to app configuration |

Check `.env.example` and `API/appsettings.json` for the current values and
ensure the API fails safely when required secrets are missing. Never put
real secrets in source control, image layers, workflow files, or README
examples.

### CI and tests

The CI workflow restores dependencies, builds in Release mode, runs the test
suite, and only builds the image after the test job succeeds. The integration
tests use Testcontainers and therefore require a working Docker engine. A
local test run that cannot connect to Docker is **blocked**, not a passing
integration-test result. Capture the successful CI run URL as evidence after
the workflow has completed.

### Before production

- Run and pass all unit and PostgreSQL/Testcontainers integration tests.
- Validate Compose and build the image on a Docker-enabled environment.
- Use a secret store for production credentials and signing keys.
- Apply EF Core migrations once through a controlled deployment step, not
  independently from every API replica.
- Verify the cycle-close and housekeeping retention settings.
- Verify seeded demo-account credentials and authentication/refresh-token
  replay behaviour from the actual seed implementation.
- Confirm the real OpenAPI/Scalar paths, CORS origins, rate limits,
  `Idempotency-Key` behaviour, and error response formats against the code.
- Capture genuine image size, build timing, CI run links, and test evidence;
  do not report unmeasured values as results.


---

# Assignment 7.2 — Responsive stokvel view

The frontend implementation and its Assignment 7.2 notes are in [`web/README.md`](web/README.md). Backend changes add status and totals to cycle responses, a required cycle ID to each contribution response, caller arrears to `/api/v1/me/home`, seed scenarios for Open/Closed/PaidOut cycles, and integration coverage in `RondiTrack.Tests/Integration/Assignment72BackendTests.cs`. The frontend README records the design choices, SA time handling, contrast calculations, test commands, and environment-dependent evidence that still needs to be captured rather than claimed without running it.

#Assignment 7.3 -Live RondiTrack Data.

The goal was to replace sample dashboard data with real API data and make authentication, retries, error handling, and stokvel switching safe.
What we did for Assignment 7.3

##Based on our previous work and the recorded branch history:
- Live API integration: connected the frontend to the RondiTrack API using generated TypeScript types, an API client, and React Query hooks.
- Authentication: worked on src/auth/session.ts so the access token stays in memory, concurrent refresh requests share

# Assignment 7.4 — Record a Contribution

## Idempotency contract

The Assignment 7.4 endpoint is `POST /api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions`. Its request body contains `userId` and numeric `amountInCents`; the amount is converted from cents to a decimal only inside the API/domain boundary. The `Idempotency-Key` is described in the OpenAPI endpoint and is passed through the typed `openapi-fetch` client and `authFetch`.

Contract from the checked-in API implementation (the running API still needs to be exercised before claiming runtime evidence):

1. **Same key, same body:** returns HTTP 201 with the stored contribution body; `Idempotency-Replayed` is `true` on replay and `false` on the first recording.
2. **Same key, changed amount or member:** returns HTTP 409 because the stored request hash differs.
3. **New key for an already-contributed member/cycle:** returns HTTP 409 with detail explaining that the member already contributed in that cycle.
4. **Rate limit:** the rate limiter returns HTTP 429 with `Retry-After` before the controller reserves the idempotency key. Retry the same key after the wait; the rejected rate-limited attempt has not consumed it.
5. **Missing key:** returns HTTP 400. The new cycle endpoint declares `Idempotency-Key` as a header parameter in the typed OpenAPI schema.
6. **CORS preflight:** `API/Program.cs` allows the configured `http://localhost:3000` origin, credentials, `POST`/`OPTIONS`, and the `Idempotency-Key` request header. It exposes `Retry-After`, `X-Correlation-ID`, and `Idempotency-Replayed` to the browser.

The form submits for the signed-in member unless the stokvel role from `/api/v1/me/home` is Treasurer. Treasurers get a picker populated by the same-stokvel members endpoint. The server independently authorizes the target against the stokvel membership, so hiding the picker is not the security boundary. The endpoint rejects a closed or paid-out cycle with HTTP 409; the service checks the idempotency cache first so an already-committed intent can still replay after the cycle closes.

The API contract above is based on the current source code, not a claim that curl/Scalar against the running PostgreSQL-backed deployment was executed. Capture the six live responses/preflight in the submission environment if the lecturer expects runtime evidence.

## Idempotency proof

The six MSW tests use MSW 2 to intercept only the HTTP network. They call the real typed API client, real `authFetch`, and the real intent-key helper with `onUnhandledRequest: 'error'`:

- network failure followed by a retry retains the same non-null key;
- successful next contribution receives a new key;
- 429 retains the key and exposes `Retry-After`;
- changing the amount after failure creates a new key and sends the changed integer-cent amount;
- 401 refresh retries with the same key and the refreshed `Authorization` token;
- the body sends `150.50` as numeric `amountInCents: 15050`.

**Deliberate-failure proof:** the single-batch script temporarily changes the key helper so a retry gets a fresh key, runs the targeted MSW suite, restores the helper, and runs the suite again. It captures both real command outputs below; the working helper is restored before build, lint, full tests, and commit.

<!-- ASSIGNMENT_7_4_PROOF_START -->
### Intentionally broken key reuse (real captured output)

Command: `CI=1 npm test -- src/contributions/recordContribution.test.ts` — exit code `1` (nonzero expected).

```text
> ronditrack-web@0.0.0 test
> vitest run src/contributions/recordContribution.test.ts


[1m[30m[46m RUN [49m[39m[22m [36mv4.1.11 [39m[90m/workspaces/RondiTrack/web[39m

 [31m❯[39m src/contributions/recordContribution.test.ts [2m([22m[2m6 tests[22m[2m | [22m[31m2 failed[39m[2m)[22m[32m 69[2mms[22m[39m
[31m     [31m×[31m retries a network failure with the same non-null key[39m[32m 33[2mms[22m[39m
     [32m✓[39m uses a new key for the next contribution after success[32m 7[2mms[22m[39m
[31m     [31m×[31m keeps the key after a 429 and exposes Retry-After[39m[32m 8[2mms[22m[39m
     [32m✓[39m starts a new intent and sends the new cents when the amount changes after failure[32m 7[2mms[22m[39m
     [32m✓[39m keeps the key across a 401 refresh and retries with the refreshed Authorization token[32m 5[2mms[22m[39m
     [32m✓[39m sends an amount typed as 150.50 across the trip as numeric 15050 cents[32m 3[2mms[22m[39m

[31m⎯⎯⎯⎯⎯⎯⎯[39m[1m[41m Failed Tests 2 [49m[22m[31m⎯⎯⎯⎯⎯⎯⎯[39m

[41m[1m FAIL [22m[49m src/contributions/recordContribution.test.ts[2m > [22mcontribution idempotency through the real API client and authFetch[2m > [22mretries a network failure with the same non-null key
[31m[1mAssertionError[22m: expected '18344920-f20c-4c0c-9e5c-9857aa17ca64' to be '98b44981-1fdf-43f6-80a4-144faae29592' // Object.is equality[39m

Expected: [32m"98b44981-1fdf-43f6-80a4-144faae29592"[39m
Received: [31m"18344920-f20c-4c0c-9e5c-9857aa17ca64"[39m

[36m [2m❯[22m src/contributions/recordContribution.test.ts:[2m56:29[22m[39m
    [90m 54|[39m     [35mawait[39m [34mexpect[39m([34mrecordContribution[39m(intent))[33m.[39mrejects[33m.[39m[34mtoThrow[39m()
    [90m 55|[39m     [35mconst[39m retryIntent [33m=[39m [34mgetContributionIntent[39m(intent[33m,[39m input)
    [90m 56|[39m     [34mexpect[39m(retryIntent[33m.[39mkey)[33m.[39m[34mtoBe[39m(intent[33m.[39mkey)
    [90m   |[39m                             [31m^[39m
    [90m 57|[39m     await expect(recordContribution(retryIntent)).resolves.toMatchObje…
    [90m 58|[39m

[31m[2m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/2]⎯[22m[39m

[41m[1m FAIL [22m[49m src/contributions/recordContribution.test.ts[2m > [22mcontribution idempotency through the real API client and authFetch[2m > [22mkeeps the key after a 429 and exposes Retry-After
[31m[1mAssertionError[22m: expected [ …(2) ] to deeply equal [ …(2) ][39m

[32m- Expected[39m
[31m+ Received[39m

[2m  [[22m
[2m    "e1c55cbe-2e83-48dd-ac09-a155fc640ea4",[22m
[32m-   "e1c55cbe-2e83-48dd-ac09-a155fc640ea4",[39m
[31m+   "0c0276af-345c-420c-a33f-aee2a31af427",[39m
[2m  ][22m

[36m [2m❯[22m src/contributions/recordContribution.test.ts:[2m105:22[22m[39m
    [90m103|[39m     [35mawait[39m [34mrecordContribution[39m(retryIntent)
    [90m104|[39m
    [90m105|[39m     [34mexpect[39m(keysSeen)[33m.[39m[34mtoEqual[39m([intent[33m.[39mkey[33m,[39m intent[33m.[39mkey])
    [90m   |[39m                      [31m^[39m
    [90m106|[39m   })
    [90m107|[39m

[31m[2m⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[2/2]⎯[22m[39m


[2m Test Files [22m [1m[31m1 failed[39m[22m[90m (1)[39m
[2m      Tests [22m [1m[31m2 failed[39m[22m[2m | [22m[1m[32m4 passed[39m[22m[90m (6)[39m
[2m   Start at [22m 05:34:08
[2m   Duration [22m 1.14s[2m (transform 118ms, setup 0ms, import 726ms, tests 69ms, environment 0ms)[22m
```

### Restored helper (real captured output)

Command: `CI=1 npm test -- src/contributions/recordContribution.test.ts` — exit code `0` (zero expected).

```text
> ronditrack-web@0.0.0 test
> vitest run src/contributions/recordContribution.test.ts


[1m[30m[46m RUN [49m[39m[22m [36mv4.1.11 [39m[90m/workspaces/RondiTrack/web[39m

 [32m✓[39m src/contributions/recordContribution.test.ts [2m([22m[2m6 tests[22m[2m)[22m[32m 62[2mms[22m[39m

[2m Test Files [22m [1m[32m1 passed[39m[22m[90m (1)[39m
[2m      Tests [22m [1m[32m6 passed[39m[22m[90m (6)[39m
[2m   Start at [22m 05:34:10
[2m   Duration [22m 504ms[2m (transform 109ms, setup 0ms, import 303ms, tests 62ms, environment 0ms)[22m
```
<!-- ASSIGNMENT_7_4_PROOF_END -->

A fresh key on every request could turn a lost response into a duplicate payment attempt instead of a replay, leaving a member unsure which request recorded their money. It also prevents the backend from recognizing a retry as the same intent, so the member may see a misleading conflict after the first request actually succeeded.

The key is generated only in the submit handler and lives in this form's component state, not module-level state or the React Query cache. React StrictMode may rerender the component, but rendering itself does not generate a key. On a network failure or HTTP response where the outcome may be unknown, the pending intent remains; changing member/amount creates a different intent, and success clears the intent. A browser reload loses the key, but the API's unique contribution-per-member/cycle rule rejects a new-key duplicate with 409 rather than recording a second contribution.

## Optimistic or not

Contribution recording is **not optimistic**. The UI waits for the server before saying “Recorded” because only the server knows the durable contribution ID, whether the cycle is still open, the new cycle total, and any updated arrears. If the frontend optimistically increased the total and the server later returned 409 (for example, the member already contributed), the member or Treasurer could act on a balance that was never committed. A meeting-ready “Recorded” message must mean the server accepted the write or replayed the already-recorded intent.

## Verification results

The following results were captured in the Codespaces terminal on 27 October 2026:

- Frontend tests: `npm test` — **52 passed across 7 test files**.
- Production build: `npm run build` — passed.
- Lint: `npm run lint` — completed with no errors and one React Compiler warning, described under Known gaps.
- Backend tests: `dotnet test RondiTrack.sln` — **40 passed, 0 failed, 0 skipped**.
- Idempotency mutation proof: temporarily breaking retry key reuse caused 2 of the 6 targeted tests to fail. After restoring the helper, all 6 targeted tests passed.
- Repository cleanup: removed the unreferenced generated project dump `COMPLETE_PROJECT.txt`, the unused React/Vite starter SVGs, and `web/src/data/sample.ts`. Historical assignment evidence and scripts were retained.

These results reflect the captured test output. They do not claim that the six API contract scenarios were exercised against a running deployment. The screen recording is also still outstanding.

## Known gaps

- The legacy backend required exactly R500 per contribution. Assignment 7.4 specifies arbitrary positive amounts carried as integer cents (including the `150.50` to `15050` example), so this implementation changes that validation to accept positive amounts with at most two decimal places. Confirm this contract with the lecturer if the original fixed-R500 rule is intended to remain mandatory.
- The frontend lint command completed with no errors and one React Compiler warning about React Hook Form's `form.watch()` usage in `web/src/components/RecordContributionForm.tsx`. Review the warning before final submission.
- Run the six idempotency-contract checks (same-key replay, same-key changed body, duplicate with new key, rate limit then retry, missing header/OpenAPI, and CORS preflight) against the running API. The README answers above are source-based until that runtime evidence is captured.
- Record the required video (two minutes or less): record a contribution; disable the network and submit; re-enable and retry while showing the same key in both requests; then record a second time and show the 409.
- The API's idempotency store is in-memory in this repository. A process restart loses cached response bodies; the existing contribution uniqueness constraint still prevents a second contribution for the same member and cycle, but a retry after process restart may receive 409 rather than replaying the original 201.

# RondiTrack — Assignment 8.1: Next.js App Router

## Overview

Assignment 8.1 introduces a Next.js App Router frontend for RondiTrack while retaining the existing Vite frontend. The Next.js application uses Server Components and Server Actions to communicate with the ASP.NET Core API. Authentication tokens are stored in an encrypted, HTTP-only session cookie rather than browser-accessible storage.

### Technology Stack

- Next.js App Router
- React and TypeScript
- ASP.NET Core Web API
- `openapi-fetch` dependency for typed API-client integration
- `jose` for encrypted session cookies
- Vitest for unit testing
- ESLint for code quality

## Running it

### Prerequisites

- Node.js and npm
- .NET SDK compatible with the RondiTrack API
- A running RondiTrack API
- Valid API credentials for testing authenticated pages

### Configure environment variables

Create `web-next/.env.local` with the following values:

```dotenv
API_BASE_URL=http://localhost:5000
SESSION_SECRET=REPLACE_WITH_A_BASE64_ENCODED_32_BYTE_SECRET
```

Use the actual API address for your environment. Generate a session secret with:

```bash
openssl rand -base64 32
```

Keep `.env.local` private and out of version control. Do not prefix server-only variables with `NEXT_PUBLIC_`.

### Install dependencies

```bash
cd web-next
npm ci
```

### Start the Next.js application

```bash
npm run dev
```

Open the development URL reported by Next.js, normally `http://localhost:3000`.

### Validate the application

```bash
npm run lint
npm test
npm run build
npm audit --audit-level=low
```

All commands should complete successfully before submission. The recorded baseline verification completed ESLint without errors, passed the three existing Vitest tests, built the production application, and reported no npm audit vulnerabilities. These results describe the checks previously run; rerun the commands against the final submitted commit to verify its current state.

## API check

The Next.js frontend communicates with the ASP.NET Core API using server-side requests.

### Authentication

The API exposes the following authentication endpoints:

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/auth/login` | Authenticate a user |
| POST | `/api/v1/auth/refresh` | Refresh an access token |
| POST | `/api/v1/auth/logout` | End the API session |

Login returns an access token in the response body and sets a `refresh_token` cookie. The Next.js server reads the cookie from the API response and stores the required tokens in its own encrypted session.

The API's configured access-token lifetime defaults to 15 minutes, subject to its configuration. The refresh-token lifetime defaults to seven days.

### Stokvel and member data

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/me/home` | Retrieve the authenticated user's stokvel memberships and home-dashboard data |
| GET | `/api/v1/stokvels/{id}` | Retrieve stokvel details |
| GET | `/api/v1/stokvels/{stokvelId}/members` | Retrieve stokvel members |
| GET | `/api/v1/stokvels/{stokvelId}/cycles` | Retrieve contribution cycles |
| GET | `/api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions` | Retrieve cycle contributions |
| POST | `/api/v1/stokvels/{stokvelId}/cycles/{cycleId}/contributions` | Record a contribution |

`GET /api/v1/me/home` returns the current user's memberships, roles, current-cycle payment information, amounts owed, arrears, and next payout dates. A user without memberships receives an empty `Stokvels` collection with HTTP 200.

`GET /api/v1/stokvels` is restricted to Platform Administrators and is not used as the ordinary member dashboard's data source.

### Recording contributions

The contribution endpoint accepts a request containing:

```json
{
  "userId": "MEMBER_GUID",
  "amountInCents": 10000
}
```

The amount is an integer in cents. The request must include an `Idempotency-Key` header. The API returns HTTP 201 for a successful new contribution or an idempotent replay, with `Idempotency-Replayed` indicating a replay.

The API remains responsible for validating the request, checking authorization, confirming that the cycle belongs to the stokvel, and enforcing contribution rules.

### API contract verification

The following behaviours must be confirmed against the running API before the implementation is considered fully verified:

- A non-member and a user requesting a nonexistent stokvel must not be able to distinguish a protected stokvel's existence from an inaccessible resource.
- The actual status codes for non-member, nonexistent, and malformed stokvel identifiers must match the frontend's error handling.
- Login and refresh responses must provide the expected access-token fields and refresh-token cookies.
- Refresh-token rotation must be handled correctly when the API issues a replacement cookie.
- Stokvel detail responses provide a member count. Current-cycle totals are obtained

# Assignment 9.3 — Deploy & Demo Day

> **Deployment status:** Repository preparation is in progress. Public production URLs,
> provider resources, Sentry event evidence, CI red/green drift demonstrations, rollback
> drill and the four-minute Demo Day recording must be added after the corresponding
> platform actions have actually been performed. Do not treat placeholders as live evidence.

## Production plan

1. **Runtime and region (proposed):** Run the Next.js server and the API as separate
   containers on Amazon ECS with AWS Fargate in `af-south-1` (Africa/Cape Town), and use
   Amazon RDS for PostgreSQL in the same region/private network. AWS lists RDS and Linux
   Fargate support in this region ([RDS regions](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Concepts.RegionsAndAvailabilityZones.html),
   [Fargate regions](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/AWS_Fargate-Regions.html)).
   The region is opt-in ([AWS region table](https://docs.aws.amazon.com/global-infrastructure/latest/regions/aws-regions.html))
   and must be enabled in the AWS account before provisioning. Confirm account availability,
   quotas and cost limits before deployment.
2. **Settings:** Set values in local `.env` files (ignored by Git) and in the relevant
   platform's secret/configuration store in production. API secrets are readable only by
   the API task role; Next.js session and Sentry build secrets are readable only by the
   frontend build/runtime roles; CI source-map credentials are GitHub Actions secrets.
   Names are listed below; values are never committed here.
3. **Startup and jobs:** Production API startup does not apply migrations or seed demo
   members. Run `scripts/deploy-migrate.sh` once as a deployment task before routing traffic.
   Development/test startup retains local migrations and sample data. Cycle closing uses a
   PostgreSQL conditional update inside a transaction; only the instance that claims the
   open cycle proceeds. Housekeeping is idempotent, though it may run on more than one
   replica. Never seed production with the local demo identities.
4. **Proxy and client IP:** The browser talks only to the Next.js BFF. The API is private
   behind the platform network/load balancer; production CORS remains closed by leaving
   `Cors:AllowedOrigins` unset entirely. Do not trust arbitrary forwarded headers. Login rate
   limiting uses a SHA-256 partition derived from the normalized login identity, not the
   shared Next.js egress IP; the raw email is not stored in the limiter key or logs. The
   in-process limiter is per API replica; use a shared gateway/distributed limiter if
   cross-replica aggregate quotas are required.
5. **Proofs:** Proof bytes are stored in PostgreSQL (`bytea`) through the
   `ContributionProofs` table, not on API container disk. They survive an API image
   redeploy only when the managed database persists. Enable encrypted automated backups,
   retention and restore tests; database loss still requires a restore. Downloads remain
   authenticated through the BFF with `private, no-store` and `nosniff`.
6. **Rollback:** Roll the frontend and API back to their previous immutable image/revision.
   Do not automatically run `Down()` migrations against financial data. Use additive,
   expand/contract migrations; take a database snapshot before schema changes. Restore a
   snapshot only under the incident procedure and verify it in a separate database first.
   Record actual rollback duration after a rehearsal.

## Live

- Frontend URL: **Pending deployment**
- API URL: **Pending deployment** (health endpoints: `/health/live`, `/health/ready`)
- Demo accounts: create synthetic accounts only after deployment, with long random passwords
  stored in the platform secret manager. Add display names only after those accounts exist.
- Never use real member or bank data in the demo environment.

## Settings

| Name | Local location | Production location | Reader |
|---|---|---|---|
| `ASPNETCORE_ENVIRONMENT` | root `.env` (`Development`) | API task setting (`Production`) | API process |
| `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` | root `.env` for local Compose | RDS database and API secret store | database/API only |
| `ConnectionStrings__RondiTrack` | root `.env` | API task secret store | API only |
| `Jwt__SigningKey` | root `.env` / user secrets | API secret store | API only |
| `CycleClose__IntervalSeconds` | root `.env` | API task config | API only |
| `Housekeeping__IntervalSeconds`, `Housekeeping__RefreshTokenRetentionDays`, `Housekeeping__IdempotencyRetentionHours` | root `.env` | API task config | API only |
| `Cors__AllowedOrigins__0` | root `.env` only for local browser-to-API development | omit entirely for BFF-only production | API only |
| `API_BASE_URL` | `web-next/.env.local` | Next.js task environment | Next.js server only |
| `NEXT_PUBLIC_SITE_URL` | `web-next/.env.local` | Next.js build/runtime config | Next.js server and Server Actions |
| `SESSION_SECRET` | `web-next/.env.local` | Next.js secret store | Next.js server only |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | local collector config | API and Next.js task config | server processes only |
| `Sentry__Dsn`, `SENTRY_DSN` | local environment | API/Next.js secret/config store | respective server runtime |
| `Sentry__Release`, `SENTRY_RELEASE`, `NEXT_PUBLIC_SENTRY_RELEASE` | local environment | build/runtime config | API/Next.js |
| `NEXT_PUBLIC_SENTRY_DSN` | `web-next/.env.local` | frontend build/runtime config | public DSN only; never an auth secret |
| `SENTRY_AUTH_TOKEN` | not committed; secret store | CI/build secret | source-map upload step only |
| `SENTRY_ORG`, `SENTRY_PROJECT` | local environment | CI/build configuration | deployment tooling |

Do not prefix secrets with `NEXT_PUBLIC_`. The Sentry DSN is a public project identifier,
not an authentication token; `SENTRY_AUTH_TOKEN` must remain server-side and build-secret-only.

## Errors

| Status | What the member sees | Next action | Owner/layer |
|---|---|---|---|
| 401 | Session ended | Sign in and return to the same safe local path | Next.js BFF/session; API Problem Details |
| 403 | Permission message in place | Stay signed in; ask a treasurer | API authorization + page/action state |
| 404 | Same not-found page for missing or inaccessible resource | Return to stokvel list | API authorization/resource policy + Next not-found |
| 409 / 422 | Conflict or validation reason | Keep input, reload current state and decide again | API Problem Details + form state |
| 429 | Retry-after message | Wait the `Retry-After` seconds | API rate limiter + BFF |
| 500 / no answer | Generic apology and safe trace reference when available | Retry or contact support with the reference | API exception middleware / Next error boundary |

The API already returns Problem Details for rate limiting with `Retry-After` and a correlation
reference. The BFF is the only browser-facing API path; do not add direct browser-to-API calls.
Verify each status on the deployed app and retain Playwright evidence before marking it complete.

## Observability

- Next.js registers `ronditrack-web` OpenTelemetry instrumentation and propagates W3C
  `traceparent` only to `API_BASE_URL`. The API ASP.NET Core instrumentation continues the
  trace; Npgsql instrumentation emits PostgreSQL spans. Configure an OTLP collector and
  `OTEL_EXPORTER_OTLP_ENDPOINT` on both server workloads.
- The API uses the active W3C trace ID as `X-Correlation-ID` in Problem Details and response
  headers. Cycle-close starts a separate background Activity and writes its South African
  local timestamp to logs.
- Sentry is optional until a DSN is configured. Both Next.js and ASP.NET Core set
  `sendDefaultPii` / `SendDefaultPii` to false. SDK before-send hooks remove user and request
  objects, request headers/cookies/query/body, breadcrumbs, extras and message text; exception
  values are replaced with a generic message while stack frames remain. The API preserves
  only the `trace_id` tag as the cross-system reference. Enable Sentry's server-side data
  scrubbing and PII filtering as a project-level backstop before sending real events.
- Evidence still required: inspect a real trace containing web, API and PostgreSQL spans;
  inspect both idempotent retry traces; inspect a cycle-close trace; capture and review a real
  Sentry event JSON field-by-field. No such live evidence is claimed by this README yet.

## Deploy and roll back

1. Provision RDS PostgreSQL in a private subnet, encrypted with automated backups and a
   documented retention/restore policy.
2. Build and publish immutable API and Next.js container images. Keep the API accessible only
   from the frontend task and trusted operations network. Terminate TLS at the load balancer.
3. Set each setting above in the proper task/secret configuration. Use different secrets for
   preview and production. Configure Sentry server-side scrubbing and the OTLP collector.
4. Run a one-off ECS task from the API image with command argument `--migrate-only`, using the
   same database secret and network configuration as the API service. Wait for successful
   completion. `scripts/deploy-migrate.sh` is the equivalent helper for local Compose.
5. Deploy API tasks, then Next.js tasks. Configure readiness checks against `/health/ready`
   and liveness against `/health/live`; route traffic only to healthy tasks.
6. Confirm CORS sends no `Access-Control-Allow-Origin` for a foreign `Origin`, confirm the
   BFF sign-in/refresh path across the two domains, upload/download a proof across an API
   redeploy, and confirm a failure reference resolves to its trace.
7. Roll back by selecting the prior immutable task/image revision. Keep the additive database
   schema compatible with both old and new application versions. Restore a database snapshot
   only through the approved recovery plan; record the rollback rehearsal time.

For local API migration: `docker compose run --build --rm api --migrate-only`.
For local contract regeneration: start the API, then run
`API_BASE_URL=http://localhost:8080 ./scripts/export-openapi.sh` and
`cd web-next && npm run api:types`.
For the CI contract check: `API_BASE_URL=http://localhost:8080 ./scripts/check-openapi.sh`.

## Runbook

**A member quotes a reference:** confirm the reference is a trace ID; search the configured
trace backend; inspect the Next.js, API and database spans; check the API's redacted logs; use
Sentry's matching `trace_id` tag if an error event exists. Never ask the member to send a token,
cookie, bank statement or full request body.

**Nobody can sign in:** check frontend/API readiness, API authentication errors and the
account-specific login limiter; verify the Next.js BFF can reach the private API; confirm
`SESSION_SECRET`, JWT signing key and refresh-cookie domain/path/secure settings are configured
in their respective secret stores. Do not loosen CORS or trust arbitrary forwarded headers.

**The cycle did not close:** check the cycle end date as `Africa/Johannesburg`, inspect the
`RondiTrack.CycleClose` trace and South African timestamp, check API logs and database
readiness, then inspect whether another instance already claimed the cycle. The conditional
claim prevents duplicate closure; retry only after understanding the transaction failure.

## Decisions

- **BFF:** browser holds no API bearer token; server-side Next.js calls the API. This avoids
  cross-site API refresh cookies and keeps the API private.
- **Closed CORS:** the browser calls only its own Next.js origin, so production API CORS remains
  closed rather than using `*` or broad origins.
- **Uniform 404:** an inaccessible resource and a nonexistent resource are intentionally
  indistinguishable to prevent resource enumeration.
- **Refresh grace:** retain the existing refresh-token rotation/grace behavior; test it across
  the deployed domains instead of changing it as part of deployment work.
- **Login throttling:** partition on a one-way hash of normalized email because requests arrive
  from the shared Next.js server address. The raw identity is not used as a key or logged.
- **Migrations:** production schema changes are a one-off deploy task, not an action every API
  replica performs on startup.

## Known gaps and hand-in evidence

- Production AWS resources, public frontend/API URLs, managed database, DNS/TLS, alarms and
  cost limits: **not provisioned by this repository batch**.
- Sentry organization/projects/DSNs, source-map upload secret, service-side scrubbing settings,
  real event JSON and issue alert: **pending platform setup and evidence**.
- OTLP collector endpoint and captured web-to-PostgreSQL trace: **pending platform setup and
  evidence**.
- API-vs-committed OpenAPI red/green demonstration, generated-type drift red run and green CI
  links: **must be produced by controlled PRs and linked here**.
- Deployed 401/403/404/409/422/429/500 flow evidence, cross-domain refresh, foreign-origin CORS,
  five-failure account-isolation test, proof persistence after redeploy, and link-preview check:
  **pending deployed verification**.
- Silent-teammate deploy/rollback test and elapsed rollback time: **pending**.
- Four-minute-or-less deployed Treasurer month-end recording: **pending**.
- Current backend suite was reported as 68/68 passing before this completion batch. Re-run the
  final full verification after all changes; do not treat the earlier result as verification of
  these additions.

## Assignment 9.3 local verification record

Verification run date: 2026-11-16

| Check | Result |
|---|---|
| Compose configuration | PASS |
| Start PostgreSQL | PASS |
| Wait for PostgreSQL | PASS |
| Stop API for migration | PASS |
| Apply database migrations | FAIL (exit 139) |
| Start API | PASS |
| Wait for API readiness | FAIL (exit 1) |
| Export OpenAPI contract | SKIPPED: API readiness check failed |
| Generate frontend API types | SKIPPED: API not ready |
| Check API contract drift | SKIPPED: API not ready |
| Backend Release build | PASS |
| Backend test suite | PASS |
| Frontend lint | PASS |
| Next.js route type generation | PASS |
| TypeScript type check | PASS |
| Frontend UTC tests | PASS |
| Frontend SAST tests | PASS |
| Playwright end-to-end tests | FAIL (exit 1) |
| Next.js production build | PASS |
| Production dependency security audit | FAIL (exit 1) |
| Whitespace and patch check | PASS |

This local verification record does not claim a production deployment. See Known gaps and hand-in evidence above for cloud deployment, live URLs, Sentry/trace evidence, rollback rehearsal and demo recording still requiring external platform setup or capture.

### Follow-up verification — 2026-11-17

| Check | Result |
|---|---|
| API liveness endpoint | PASS (HTTP 200) |
| API readiness endpoint | PASS (HTTP 200) |
| OpenAPI export | PASS |
| OpenAPI contract drift check | PASS |
| Frontend API type generation | PASS |
| Next.js Docker image build | PASS (`ronditrack-web:9.3`) |

The API and PostgreSQL connection was verified in the Codespaces environment using the Codespaces Compose network override. This does not resolve or replace the outstanding migration exit 139, Playwright E2E, or production dependency audit failures recorded above. Production deployment and Demo Day evidence remain pending.
