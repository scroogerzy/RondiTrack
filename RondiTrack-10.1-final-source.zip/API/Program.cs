using Sentry.Extensibility;
using Sentry;
using RondiTrack.API.Observability;
using OpenTelemetry.Trace;
using OpenTelemetry.Metrics;
using OpenTelemetry;
using OpenTelemetry.Resources;

using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.EntityFrameworkCore;
using Scalar.AspNetCore;
using RondiTrack.Domain.Repositories;
using RondiTrack.Infrastructure.Data;
using RondiTrack.API.Data;
using RondiTrack.Middleware;
using RondiTrack.Domain.Models;
using RondiTrack.Services;
using RondiTrack.Validators;
using RondiTrack.Auth;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;
using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Serialization;
using RondiTrack.Common;
using RondiTrack.API.Services.BackgroundJobs;

var migrateOnly = args.Any(arg => string.Equals(arg, "--migrate-only", StringComparison.OrdinalIgnoreCase));
var builderArgs = args.Where(arg => !string.Equals(arg, "--migrate-only", StringComparison.OrdinalIgnoreCase)).ToArray();
var builder = WebApplication.CreateBuilder(builderArgs);

// Authentication settings: the signing key must come from user-secrets or environment configuration.
var jwtSection = builder.Configuration.GetSection(JwtOptions.SectionName);
var jwtOptions = jwtSection.Get<JwtOptions>() ?? new JwtOptions();
if (string.IsNullOrWhiteSpace(jwtOptions.SigningKey) || Encoding.UTF8.GetByteCount(jwtOptions.SigningKey) < 32)
    throw new InvalidOperationException("JWT signing key is missing or too short. Set Jwt:SigningKey in user-secrets (at least 32 bytes). Tests must override Jwt:SigningKey in the test factory.");
if (jwtOptions.AccessTokenMinutes is < 1 or > 15)
    throw new InvalidOperationException("Jwt:AccessTokenMinutes must be between 1 and 15.");

builder.Services.Configure<JwtOptions>(jwtSection);
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true, ValidIssuer = jwtOptions.Issuer,
            ValidateAudience = true, ValidAudience = jwtOptions.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.SigningKey)),
            ValidAlgorithms = [SecurityAlgorithms.HmacSha256],
            ValidateLifetime = true, ClockSkew = TimeSpan.FromSeconds(30),
            NameClaimType = JwtRegisteredClaimNames.Sub,
            RoleClaimType = "role"
        };
    });

builder.Services.AddAuthorizationBuilder()
    .AddPolicy(Policies.StokvelMember, policy => policy.AddRequirements(new StokvelAccessRequirement()))
    .AddPolicy(Policies.StokvelManager, policy => policy.AddRequirements(new StokvelAccessRequirement(managerRequired: true)))
    .AddPolicy(Policies.RecordContribution, policy => policy.AddRequirements(new RecordContributionRequirement()))
    .SetFallbackPolicy(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
builder.Services.AddScoped<IAuthorizationHandler, StokvelAccessHandler>();
builder.Services.AddScoped<IAuthorizationHandler, RecordContributionHandler>();

builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<TokenService>();
builder.Services.AddSingleton<IPasswordHasher<User>, PasswordHasher<User>>();
builder.Services.AddScoped<IRefreshTokenRepository, EfRefreshTokenRepository>();
builder.Services.AddScoped<AuthService>();

// Register MVC controllers.
builder.Services.AddControllers(options =>
{
    options.SuppressAsyncSuffixInActionNames = false;
})
.AddJsonOptions(options =>
{
    options.JsonSerializerOptions.NumberHandling = JsonNumberHandling.Strict;
})
.ConfigureApiBehaviorOptions(options =>
{
    options.SuppressModelStateInvalidFilter = false;

    options.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState
            .Where(entry => entry.Value?.Errors.Count > 0)
            .ToDictionary(
                entry => JsonNamingPolicy.CamelCase.ConvertName(entry.Key),
                entry => entry.Value!.Errors
                    .Select(error => string.IsNullOrWhiteSpace(error.ErrorMessage)
                        ? "The supplied value is invalid."
                        : error.ErrorMessage)
                    .ToArray());

        var problem = new ValidationProblemDetails(errors)
        {
            Type = "https://api.ronditrack.co.za/errors/validation",
            Title = "One or more validation errors occurred.",
            Status = StatusCodes.Status400BadRequest,
            Detail = "Correct the supplied fields and try again.",
            Instance = context.HttpContext.Request.Path
        };
        problem.Extensions["correlationId"] =
            context.HttpContext.Items["X-Correlation-ID"]?.ToString()
            ?? context.HttpContext.TraceIdentifier;

        return new BadRequestObjectResult(problem)
        {
            ContentTypes = { "application/problem+json" }
        };
    };
});

// Also configure minimal-API/HTTP JSON options so OpenAPI and runtime
// use the same strict numeric contract.
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.NumberHandling = JsonNumberHandling.Strict;
});

// Register automatic request validation.
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<CreateUserRequestValidator>();

// Register API documentation.
builder.Services.AddOpenApi();
builder.Services.AddProblemDetails();

// Configure EF Core to use PostgreSQL.
builder.Services.AddDbContext<RondiTrackDbContext>(options =>
{
    options.UseNpgsql(
        builder.Configuration.GetConnectionString("RondiTrack"));
});

// Register database-backed repositories.
builder.Services.AddScoped<IUserRepository, EfUserRepository>();
builder.Services.AddScoped<IStokvelRepository, EfStokvelRepository>();

// StokvelMember uses a composite primary key and its own repository.
builder.Services.AddScoped<
    IStokvelMemberRepository,
    EfStokvelMemberRepository>();

// Contributions and cycles use the same PostgreSQL database.
builder.Services.AddScoped<
    IContributionRepository,
    EfContributionRepository>();

builder.Services.AddScoped<
    IContributionCycleRepository,
    EfContributionCycleRepository>();

// Idempotency receipts share the request DbContext and transaction.
builder.Services.AddScoped<IIdempotencyStore, EfIdempotencyStore>();

// Register the business service.
builder.Services.AddScoped<IStokvelService, StokvelService>();

// Assignment 6.2: OpenTelemetry traces, metrics and logs.
builder.Services.AddSingleton<RondiTrackMetrics>();
builder.Services.AddHostedService<CycleCloseBackgroundService>();
builder.Services.AddHostedService<HousekeepingBackgroundService>();

var telemetry = builder.Services.AddOpenTelemetry()
    .ConfigureResource(resource => resource.AddService("ronditrack-api"))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation(options =>
            options.Filter = context =>
                !context.Request.Path.StartsWithSegments("/health"))
        .AddSource("Npgsql")
        .AddSource("RondiTrack.CycleClose")
        .AddSource(RondiTrack.Services.RondiTrackActivity.Source.Name))
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation()
        .AddMeter("System.Runtime")
        .AddMeter(RondiTrackMetrics.MeterName))
    .WithLogging();

if (!string.IsNullOrWhiteSpace(
        builder.Configuration["OTEL_EXPORTER_OTLP_ENDPOINT"]))
{
    telemetry.UseOtlpExporter();
}

// PostgreSQL readiness check; liveness does not depend on the database.
builder.Services.AddHealthChecks()
    .AddDbContextCheck<RondiTrackDbContext>(
        name: "postgres",
        tags: new[] { "ready" });


// Exact-origin CORS: credentials cannot be combined with a wildcard origin.
var allowedOrigins = builder.Configuration
    .GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(options =>
{
    options.AddPolicy(CorsPolicies.Frontend, policy =>
    {
        if (allowedOrigins.Length > 0)
            policy.WithOrigins(allowedOrigins);
        policy.WithMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS");
        policy.WithHeaders("Authorization", "Content-Type", "Idempotency-Key", "X-Correlation-ID");
        policy.WithExposedHeaders("Retry-After", "X-Correlation-ID", "Idempotency-Replayed");
        policy.AllowCredentials().SetPreflightMaxAge(TimeSpan.FromMinutes(10));
    });
});

// Login is partitioned by client IP. Financial writes are partitioned by
// authenticated subject, so users sharing venue Wi-Fi do not share money limits.
var loginPermitLimit = builder.Configuration.GetValue("RateLimiting:Login:PermitLimit", 5);
var loginWindowSeconds = builder.Configuration.GetValue("RateLimiting:Login:WindowSeconds", 60);
var contributionPermitLimit = builder.Configuration.GetValue("RateLimiting:Contributions:PermitLimit", 25);
var contributionWindowSeconds = builder.Configuration.GetValue("RateLimiting:Contributions:WindowSeconds", 60);
var payoutPermitLimit = builder.Configuration.GetValue("RateLimiting:Payouts:PermitLimit", 5);
var payoutWindowSeconds = builder.Configuration.GetValue("RateLimiting:Payouts:WindowSeconds", 60);

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.OnRejected = async (context, cancellationToken) =>
    {
        var response = context.HttpContext.Response;
        response.StatusCode = StatusCodes.Status429TooManyRequests;
        response.ContentType = "application/problem+json";
        var retryAfterSeconds = context.Lease.TryGetMetadata(
            MetadataName.RetryAfter, out var retryAfter)
            ? Math.Max(1, (int)Math.Ceiling(retryAfter.TotalSeconds))
            : 1;
        response.Headers["Retry-After"] = retryAfterSeconds.ToString();

        var correlationId = context.HttpContext.Items["X-Correlation-ID"]?.ToString()
            ?? context.HttpContext.TraceIdentifier;
        var problem = new Microsoft.AspNetCore.Mvc.ProblemDetails
        {
            Type = "https://api.ronditrack.co.za/errors/rate-limit",
            Title = "Too Many Requests",
            Status = StatusCodes.Status429TooManyRequests,
            Detail = "The request limit has been reached. Wait before retrying.",
            Instance = context.HttpContext.Request.Path
        };
        problem.Extensions["correlationId"] = correlationId;
        await JsonSerializer.SerializeAsync(response.Body, problem, cancellationToken: cancellationToken);
    };

    options.AddPolicy(RateLimitPolicies.Login, httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: httpContext.Items[LoginRateLimitKeyMiddleware.ItemKey]?.ToString()
                ?? $"ip:{httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown-ip"}",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = Math.Max(1, loginPermitLimit),
                Window = TimeSpan.FromSeconds(Math.Max(1, loginWindowSeconds)),
                QueueLimit = 0,
                AutoReplenishment = true
            }));

    options.AddPolicy(RateLimitPolicies.Invites, httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: httpContext.User.FindFirstValue(JwtRegisteredClaimNames.Sub)
                ?? httpContext.Connection.RemoteIpAddress?.ToString()
                ?? "unknown-client",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0,
                AutoReplenishment = true
            }));

    options.AddPolicy(RateLimitPolicies.Contributions, httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: httpContext.User.FindFirstValue(JwtRegisteredClaimNames.Sub)
                ?? httpContext.User.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? "anonymous",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = Math.Max(1, contributionPermitLimit),
                Window = TimeSpan.FromSeconds(Math.Max(1, contributionWindowSeconds)),
                QueueLimit = 0,
                AutoReplenishment = true
            }));

    options.AddPolicy(RateLimitPolicies.Payouts, httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: httpContext.User.FindFirstValue(JwtRegisteredClaimNames.Sub)
                ?? httpContext.User.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? "anonymous",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = Math.Max(1, payoutPermitLimit),
                Window = TimeSpan.FromSeconds(Math.Max(1, payoutWindowSeconds)),
                QueueLimit = 0,
                AutoReplenishment = true
            }));
});

var sentryDsn = builder.Configuration["Sentry:Dsn"];
if (!string.IsNullOrWhiteSpace(sentryDsn))
{
    builder.WebHost.UseSentry(options =>
    {
        options.Dsn = sentryDsn;
        options.SendDefaultPii = false;
        options.MaxRequestBodySize = RequestSize.None;
        options.Release = builder.Configuration["Sentry:Release"];
        options.SetBeforeSend(SentryPrivacyScrubber.Scrub);
        options.SetBeforeBreadcrumb(_ => null);
    });
}

var app = builder.Build();

// Deployment runs migrations as a one-off task before new API replicas receive traffic.
// `dotnet API.dll --migrate-only` exits after applying migrations and never seeds demo data.
if (migrateOnly)
{
    await using var migrationScope = app.Services.CreateAsyncScope();
    var migrationDb = migrationScope.ServiceProvider.GetRequiredService<RondiTrackDbContext>();
    await migrationDb.Database.MigrateAsync();
    return;
}

// Seed local/test environments only. Production databases must be provisioned
// deliberately and must never receive hard-coded demo identities or financial records.
if (app.Environment.IsDevelopment() || app.Environment.IsEnvironment("Testing"))
{
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider
        .GetRequiredService<RondiTrackDbContext>();

    await dbContext.Database.MigrateAsync();

    // Seed starter users only if the Users table is empty.
    if (!await dbContext.Users.AnyAsync())
    {
        dbContext.Users.AddRange(
            new User("Thabo Mokoena", "thabo@example.com"),
            new User("Lerato Dlamini", "lerato@example.com"),
            new User("Sibusiso Ndlovu", "sibusiso@example.com"));

        await dbContext.SaveChangesAsync();
    }

    // Preserve the starter stokvels that were previously provided
    // by InMemoryStokvelRepository.
    if (!await dbContext.Stokvels.AnyAsync())
    {
        dbContext.Stokvels.AddRange(
            new Stokvel("Ubuntu Savings Club", 500m),
            new Stokvel("Mzanzi Monthly Stokvel", 500m));

        await dbContext.SaveChangesAsync();
    }

    // Assignment 7.2 demo memberships intentionally give the same signed-in
    // user different per-stokvel roles (Treasurer and Member).
    var seedUsers = await dbContext.Users.OrderBy(user => user.Email).ToListAsync();
    var starterEmails = new[] { "lerato@example.com", "sibusiso@example.com", "thabo@example.com" };
    var starterUsers = seedUsers.Where(user => starterEmails.Contains(user.Email, StringComparer.OrdinalIgnoreCase)).ToList();
    var demoUser = seedUsers.FirstOrDefault(user =>
        string.Equals(user.Email, "lerato@example.com", StringComparison.OrdinalIgnoreCase))
        ?? seedUsers.FirstOrDefault();
    var seedStokvels = await dbContext.Stokvels.ToListAsync();
    var treasurerStokvel = seedStokvels.FirstOrDefault(stokvel => stokvel.Name == "Ubuntu Savings Club");
    var memberStokvel = seedStokvels.FirstOrDefault(stokvel => stokvel.Name == "Mzanzi Monthly Stokvel");

    if (demoUser is not null)
    {
        foreach (var stokvel in seedStokvels.Where(stokvel =>
            stokvel.Id == treasurerStokvel?.Id || stokvel.Id == memberStokvel?.Id))
        {
            var desiredRole = stokvel.Id == treasurerStokvel?.Id
                ? RondiTrack.Auth.StokvelRoles.Treasurer
                : stokvel.Id == memberStokvel?.Id
                    ? RondiTrack.Auth.StokvelRoles.Member
                    : RondiTrack.Auth.StokvelRoles.Member;
            var membership = await dbContext.StokvelMembers.FirstOrDefaultAsync(member =>
                member.UserId == demoUser.Id && member.StokvelId == stokvel.Id);
            if (membership is null)
                dbContext.StokvelMembers.Add(new StokvelMember(
                    demoUser.Id, stokvel.Id, desiredRole, DateTime.UtcNow));
            else
                membership.UpdateRole(desiredRole);
        }

        // Other starter users belong to the seeded family stokvel too, so
        // collected totals and target amounts have realistic member counts.
        if (treasurerStokvel is not null)
        {
            foreach (var otherUser in starterUsers.Where(user => user.Id != demoUser.Id))
            {
                var membership = await dbContext.StokvelMembers.FirstOrDefaultAsync(member =>
                    member.UserId == otherUser.Id && member.StokvelId == treasurerStokvel.Id);
                if (membership is null)
                    dbContext.StokvelMembers.Add(new StokvelMember(
                        otherUser.Id, treasurerStokvel.Id,
                        RondiTrack.Auth.StokvelRoles.Member, DateTime.UtcNow));
                else
                    membership.UpdateRole(RondiTrack.Auth.StokvelRoles.Member);
            }
        }
        await dbContext.SaveChangesAsync();
    }

    // Seed three periods for Assignment 7.2: an open cycle, a closed cycle
    // with the demo member in arrears, and a paid-out cycle. The operation is
    // idempotent and does not create duplicates on subsequent restarts.
    if (demoUser is not null && treasurerStokvel is not null && starterUsers.Count >= 3)
    {
        var utc = DateTimeKind.Utc;
        var cycleDefinitions = new[]
        {
            new { Period = 2, Start = new DateTime(2026, 8, 1, 0, 0, 0, utc), End = new DateTime(2026, 8, 31, 22, 0, 0, utc), Status = "PaidOut" },
            new { Period = 3, Start = new DateTime(2026, 9, 1, 0, 0, 0, utc), End = new DateTime(2026, 9, 30, 22, 0, 0, utc), Status = "Closed" },
            new { Period = 4, Start = new DateTime(2026, 10, 1, 0, 0, 0, utc), End = new DateTime(2026, 10, 31, 22, 0, 0, utc), Status = "Open" }
        };
        foreach (var definition in cycleDefinitions)
        {
            var cycle = await dbContext.ContributionCycles.FirstOrDefaultAsync(item =>
                item.StokvelId == treasurerStokvel.Id && item.PeriodNumber == definition.Period);
            if (cycle is null)
            {
                cycle = new ContributionCycle(treasurerStokvel.Id, definition.Period,
                    definition.Start, definition.End, 1500m);
                if (definition.Status is "Closed" or "PaidOut")
                    cycle.TryClose(new DateTime(2026, definition.Period == 2 ? 9 : 10, 1, 0, 0, 0, utc));
                if (definition.Status == "PaidOut")
                    cycle.ProcessPayout(new DateTime(2026, 9, 2, 0, 0, 0, utc));
                dbContext.ContributionCycles.Add(cycle);
            }
        }
        await dbContext.SaveChangesAsync();

        var contributionUsersByPeriod = new Dictionary<int, Guid[]>
        {
            [2] = starterUsers.Select(user => user.Id).ToArray(),
            [3] = starterUsers.Where(user => user.Id != demoUser.Id).Select(user => user.Id).ToArray(),
            [4] = new[] { demoUser.Id, starterUsers.First(user => user.Id != demoUser.Id).Id }
        };
        foreach (var pair in contributionUsersByPeriod)
        {
            foreach (var userId in pair.Value)
            {
                var exists = await dbContext.Contributions.AnyAsync(contribution =>
                    contribution.StokvelId == treasurerStokvel.Id &&
                    contribution.UserId == userId && contribution.Cycle == pair.Key);
                if (!exists)
                    dbContext.Contributions.Add(new Contribution(
                        treasurerStokvel.Id, userId, pair.Key, 500m));
            }
        }

        var arrearsExists = await dbContext.ArrearRecords.AnyAsync(arrear =>
            arrear.StokvelId == treasurerStokvel.Id && arrear.UserId == demoUser.Id &&
            arrear.CyclePeriodNumber == 3);
        if (!arrearsExists)
            dbContext.ArrearRecords.Add(new ArrearRecord(
                treasurerStokvel.Id, demoUser.Id, 3, 50_000,
                new DateTime(2026, 10, 1, 0, 0, 0, utc)));
        await dbContext.SaveChangesAsync();
    }
}

}

// Liveness checks the process only. Readiness checks PostgreSQL.
app.MapHealthChecks("/health/live", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = _ => false,
    ResponseWriter = async (context, report) =>
        await context.Response.WriteAsync(report.Status.ToString())
}).AllowAnonymous();

app.MapHealthChecks("/health/ready", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = async (context, report) =>
        await context.Response.WriteAsync(report.Status.ToString())
}).AllowAnonymous();


// The versioned OpenAPI JSON is public so CI and the committed contract can be compared.
// Keep the interactive Scalar UI limited to Development.
app.MapOpenApi().AllowAnonymous();
if (app.Environment.IsDevelopment())
    app.MapScalarApiReference().AllowAnonymous();

// Register middleware in the existing request pipeline.
app.UseRouting();
app.UseCors(CorsPolicies.Frontend);
app.UseMiddleware<CorrelationIdMiddleware>();
app.UseMiddleware<ExceptionHandlingMiddleware>();

app.UseStatusCodePages(async context =>
{
    var httpContext = context.HttpContext;
    var response = httpContext.Response;

    if (response.HasStarted) return;

    var status = response.StatusCode;
    var title = status switch
    {
        StatusCodes.Status400BadRequest => "Bad Request",
        StatusCodes.Status401Unauthorized => "Unauthorized",
        StatusCodes.Status403Forbidden => "Forbidden",
        StatusCodes.Status404NotFound => "Not Found",
        StatusCodes.Status405MethodNotAllowed => "Method Not Allowed",
        _ => "Request failed"
    };

    var problem = new Microsoft.AspNetCore.Mvc.ProblemDetails
    {
        Type = $"https://api.ronditrack.co.za/errors/{status}",
        Title = title,
        Status = status,
        Detail = status switch
        {
            StatusCodes.Status400BadRequest => "The request could not be processed.",
            StatusCodes.Status401Unauthorized => "Authentication is required or the supplied credentials are invalid.",
            StatusCodes.Status403Forbidden => "You do not have permission to perform this operation.",
            StatusCodes.Status404NotFound => "The requested resource was not found.",
            StatusCodes.Status405MethodNotAllowed => "The HTTP method is not supported for this resource.",
            _ => "The request could not be completed."
        },
        Instance = httpContext.Request.Path
    };
    problem.Extensions["correlationId"] =
        httpContext.Items["X-Correlation-ID"]?.ToString()
        ?? httpContext.TraceIdentifier;

    response.ContentType = "application/problem+json";
    await System.Text.Json.JsonSerializer.SerializeAsync(
        response.Body,
        problem,
        cancellationToken: httpContext.RequestAborted);
});
app.UseAuthentication();
app.UseMiddleware<LoginRateLimitKeyMiddleware>();
app.UseRateLimiter();
app.UseAuthorization();

app.MapControllers();

app.Run();
