using RondiTrack.DTOs.Contributions;

namespace RondiTrack.API.Data;

/// <summary>
/// Stores the result of an idempotent operation so that
/// retries can return the original response.
/// </summary>
public interface IIdempotencyStore
{
    /// <summary>
    /// Finds an existing idempotency record using its key.
    /// </summary>
    Task<IdempotencyRecord?> FindAsync(string key);

    /// <summary>
    /// Atomically reserves an idempotency key.
    /// </summary>
    Task<bool> TryReserveAsync(string key, string requestHash);

    /// <summary>Runs the contribution write and idempotency receipt in one transaction.</summary>
    Task<T> ExecuteAtomicallyAsync<T>(Func<Task<T>> operation);

    /// <summary>
    /// Stores the request hash and original response for an idempotency key.
    /// </summary>
    Task SaveAsync(
        string key,
        IdempotencyRecord record);

    /// <summary>Removes entries reserved before the supplied UTC cutoff.</summary>
    Task<int> RemoveOlderThanAsync(DateTime cutoffUtc);
}

/// <summary>
/// Represents the information stored for an idempotent request.
/// </summary>
public record IdempotencyRecord(
    string RequestHash,
    ContributionResponse? ResponseBody);